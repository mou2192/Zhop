# -*- coding: utf-8 -*-
"""دوال مساعدة صغيرة (معرّفات، أرقام، بيانات البائع...)."""

import random
import string
from datetime import datetime
from paths import IS_ANDROID


def gen_id():
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    rand = "".join(random.choices(string.ascii_lowercase + string.digits, k=6))
    return f"{ts}_{rand}"


def get_device_name():
    try:
        if IS_ANDROID:
            from jnius import autoclass
            B = autoclass("android.os.Build")
            return ("%s %s" % (B.MANUFACTURER, B.MODEL)).strip()[:40] or "جهاز"
    except Exception:
        pass
    try:
        import socket
        return socket.gethostname()[:40] or "جهاز"
    except Exception:
        return "جهاز"


SELLER = {"name": "", "shop": "", "loc": "", "phone": ""}


def set_seller(user):
    user = user or {}
    for k in SELLER:
        SELLER[k] = str(user.get(k, "") or "")


def seller_lines():
    out = []
    if SELLER.get("shop"):
        out.append(SELLER["shop"])
    if SELLER.get("phone"):
        out.append("للتواصل: " + SELLER["phone"])
    return out


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def now_full():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def money(v):
    try:
        return f"{v:,.0f}"
    except Exception:
        return "0"


def money_signed(v):
    try:
        if v < 0:
            return "-" + f"{abs(v):,.0f}"
        return f"{v:,.0f}"
    except Exception:
        return "0"


def looks_like_font(path):
    """يتأكد أن الملف خط حقيقي (OTF/TTF/TTC) وليس صفحة خطأ أو ملفاً تالفاً."""
    try:
        with open(path, "rb") as f:
            head = f.read(4)
        return head in (b"OTTO", b"\x00\x01\x00\x00", b"true", b"ttcf")
    except Exception:
        return False
