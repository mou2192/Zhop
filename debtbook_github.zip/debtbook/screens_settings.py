# -*- coding: utf-8 -*-
"""شاشات: المزامنة، الإعدادات، كلمة المرور، بيانات البائع، الأجهزة، الحسابات."""

import threading
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import Screen
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from telegram_db import DB, TgError
from theme import (BLUE, GRAY_BTN, GREEN, HEADER, MUTED, ORANGE, PRIMARY, RED, TEXT,
    is_dark, register_theme)
from widgets import (CardBox, make_arabic_popup, make_body, make_header,
    make_scroll_list, mk_btn, mk_input, mk_text)

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


class SyncScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.build_ui()

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header("مزامنة", HEADER))
        body = BoxLayout(orientation="vertical", spacing=dp(20),
                         padding=[dp(24), dp(80), dp(24), dp(24)])
        self.msg_dt = mk_text("جاري المزامنة...", dp(20), PRIMARY,
                              halign="center", height=dp(40))
        body.add_widget(self.msg_dt)
        self.sub_dt = mk_text("", dp(14), MUTED, halign="center", height=dp(30))
        body.add_widget(self.sub_dt)
        body.add_widget(Widget())
        self.close_btn = mk_btn("إغلاق", height=dp(52),
                                background_color=GRAY_BTN)
        self.close_btn.bind(on_release=lambda *a: self.app.go_main())
        body.add_widget(self.close_btn)
        root.add_widget(body)
        self.add_widget(root)

    def set_status(self, main, sub=""):
        self.msg_dt.text = main
        self.sub_dt.text = sub


class SettingsScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.build_ui()

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header("الإعدادات", HEADER,
                                    on_back=lambda *a: self.app.go_main()))
        sv = ScrollView(size_hint=(1, 1), bar_width=dp(3))
        body = BoxLayout(orientation="vertical", spacing=dp(10),
                         padding=[dp(14), dp(12), dp(14), dp(14)],
                         size_hint_y=None)
        body.bind(minimum_height=body.setter("height"))

        user = self.app.data.get("user") or {}
        card = CardBox(orientation="vertical", size_hint_y=None,
                       height=dp(310), padding=[dp(14), dp(10)],
                       spacing=dp(2))
        card.add_widget(mk_text("معلومات الحساب", dp(16), PRIMARY,
                                height=dp(32)))
        for label, key in (("الاسم", "name"),
                           ("اسم المشروع / الدكان", "shop"),
                           ("موقع الدكان", "loc"),
                           ("رقم التاجر", "phone"),
                           ("البريد الإلكتروني", "email")):
            card.add_widget(mk_text(label, dp(12), MUTED, height=dp(20)))
            card.add_widget(mk_text(user.get(key, "") or "-", dp(15), TEXT,
                                    height=dp(28)))
        body.add_widget(card)

        def add_btn(text, color, cb):
            b = mk_btn(text, height=dp(50), font_size=dp(16),
                       background_color=color)
            b.bind(on_release=cb)
            body.add_widget(b)

        add_btn("تعديل بيانات البائع", BLUE, self.app.open_edit_profile)
        add_btn("تغيير كلمة المرور", BLUE, self.app.open_change_password)
        add_btn("الأجهزة المتصلة بالحساب", BLUE, self.app.open_devices)
        add_btn("الحسابات )تبديل / إضاف(", BLUE, self.app.open_accounts)
        add_btn("تغيير الخط", BLUE, self.app.open_fonts)
        add_btn("الوضع النهاري" if is_dark() else "الوضع الليلي", ORANGE,
                self.app.toggle_theme)
        add_btn("تسجيل الخروج", GRAY_BTN, self.confirm_logout)
        add_btn("حذف الحساب", RED, self.confirm_delete_account)

        body.add_widget(mk_text("تسجيل الخروج يُبقي بياناتك محفوظة على الجهاز "
                                "وعلى الانترنت اذا عملت مزامنه. حذف الحساب يمسح كل شيء نهائياً.",
                                dp(12), MUTED, halign="center", height=dp(48)))
        sv.add_widget(body)
        root.add_widget(sv)
        self.add_widget(root)

    # ---------- تسجيل الخروج ----------
    def confirm_logout(self, *a):
        content = BoxLayout(orientation="vertical", spacing=dp(10),
                            padding=dp(12))
        content.add_widget(mk_text("هل تريد تسجيل الخروج؟", dp(16), TEXT,
                                   halign="center", height=dp(40)))
        content.add_widget(mk_text("اضغط مزامنة قبل الخروج لرفع آخر التغييرات",
                                   dp(13), MUTED, halign="center",
                                   height=dp(44)))
        content.add_widget(Widget())
        bb = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        yes = mk_btn("نعم", background_color=RED)
        no = mk_btn("إلغاء", background_color=GRAY_BTN)
        bb.add_widget(yes)
        bb.add_widget(no)
        content.add_widget(bb)
        popup = make_arabic_popup("خروج", content, size_hint=(0.88, 0.42),
                                  title_color=RED, separator_color=RED)

        def do(*a):
            popup.dismiss()
            self.app.do_logout()

        yes.bind(on_release=do)
        no.bind(on_release=lambda *a: popup.dismiss())
        popup.open()

    # ---------- حذف الحساب ----------
    def confirm_delete_account(self, *a):
        content = BoxLayout(orientation="vertical", spacing=dp(6),
                            padding=dp(10))
        content.add_widget(mk_text(
            "سيُحذف حسابك وكل عملائك وفواتيرك من هذا الجهاز ومن الانترنت نهائياً",
            dp(14), RED, halign="center", height=dp(64)))
        content.add_widget(mk_text("اكتب كلمة المرور للتأكيد", dp(13), MUTED,
                                   height=dp(22)))
        pw_in = mk_input(hint_text="********", size_hint_y=None,
                         height=dp(48))
        content.add_widget(pw_in)
        msg = mk_text("", dp(13), RED, halign="center", height=dp(28))
        content.add_widget(msg)
        content.add_widget(Widget())
        bb = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        yes = mk_btn("حذف نهائي", background_color=RED)
        no = mk_btn("إلغاء", background_color=GRAY_BTN)
        bb.add_widget(yes)
        bb.add_widget(no)
        content.add_widget(bb)
        popup = make_arabic_popup("حذف الحساب", content, size_hint=(0.92, 0.62),
                                  title_color=RED, separator_color=RED,
                                  auto_dismiss=False)
        busy = {"v": False}

        def done(ok, err):
            busy["v"] = False
            if ok:
                popup.dismiss()
                self.app.wipe_local_and_restart()
            else:
                msg.text = err or "فشل الحذف"

        def do(*a):
            if busy["v"]:
                return
            password = pw_in.text.strip()
            if not password:
                msg.text = "أدخل كلمة المرور"
                return
            busy["v"] = True
            msg.text = "جاري الحذف..."

            def worker():
                ok, err = self.app.delete_account_remote(password)
                Clock.schedule_once(lambda dt: done(ok, err), 0)

            threading.Thread(target=worker, daemon=True).start()

        yes.bind(on_release=do)
        no.bind(on_release=lambda *a: (None if busy["v"] else popup.dismiss()))
        popup.open()


ACC_KEYS = ("user", "clients", "_deleted", "_tg_meta", "_sv", "_dev_ok", "owner")


class FormScreen(Screen):
    TITLE = ""
    SAVE_TEXT = "حفظ"
    _busy = False

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.build_ui()

    def fields(self, body):
        pass

    def labeled(self, body, label, hint="", text="", **kw):
        body.add_widget(mk_text(label, dp(13), MUTED, height=dp(22)))
        w = mk_input(hint_text=hint, size_hint_y=None, height=dp(50), **kw)
        if text:
            w.text = text
        body.add_widget(w)
        return w

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header(
            self.TITLE, HEADER,
            on_back=lambda *a: self.app.open_settings(back=True)))
        sv = ScrollView(size_hint=(1, 1))
        body = BoxLayout(orientation="vertical", spacing=dp(8),
                         padding=[dp(24), dp(16), dp(24), dp(20)],
                         size_hint_y=None)
        body.bind(minimum_height=body.setter("height"))
        self.fields(body)
        self.msg_dt = mk_text("", dp(13), RED, halign="center", height=dp(28))
        body.add_widget(self.msg_dt)
        btn = mk_btn(self.SAVE_TEXT, height=dp(52), font_size=dp(18),
                     background_color=GREEN)
        btn.bind(on_release=self.on_save)
        body.add_widget(btn)
        sv.add_widget(body)
        root.add_widget(sv)
        self.add_widget(root)

    def on_save(self, *a):
        pass

    def run(self, work, on_ok):
        if self._busy:
            return
        self._busy = True
        self.msg_dt.text = "جاري الحفظ..."

        def w():
            try:
                ok, res = work()
            except TgError as e:
                ok, res = False, str(e)
            except Exception as e:
                ok, res = False, str(e)[:60]
            Clock.schedule_once(lambda dt: self._done(ok, res, on_ok), 0)

        threading.Thread(target=w, daemon=True).start()

    def _done(self, ok, res, on_ok):
        self._busy = False
        if ok:
            self.msg_dt.text = ""
            on_ok()
        else:
            self.msg_dt.text = res or "فشلت العملية"


class ChangePasswordScreen(FormScreen):
    TITLE = "تغيير كلمة المرور"

    def fields(self, body):
        self.old_in = self.labeled(body, "كلمة المرور الحالية", "********")
        self.new_in = self.labeled(body, "كلمة المرور الجديدة", "********")
        self.conf_in = self.labeled(body, "تأكيد كلمة المرور الجديدة", "********")
        body.add_widget(mk_text(
            "عند التغيير سيتم تسجيل الخروج من جميع الأجهزة الأخرى.",
            dp(12), MUTED, halign="center", height=dp(26)))

    def on_save(self, *a):
        old = self.old_in.text.strip()
        new = self.new_in.text.strip()
        if not old:
            self.msg_dt.text = "أدخل كلمة المرور الحالية"
            return
        if len(new) < 4:
            self.msg_dt.text = "كلمة المرور الجديدة قصيرة جداً"
            return
        if new != self.conf_in.text.strip():
            self.msg_dt.text = "كلمتا المرور غير متطابقتين"
            return
        self.run(lambda: self.app.change_password_remote(old, new),
                 lambda: self.app.open_settings(back=True))


class EditProfileScreen(FormScreen):
    TITLE = "تعديل بيانات البائع"

    def fields(self, body):
        u = self.app.data.get("user") or {}
        self.name_in = self.labeled(body, "الاسم", "", u.get("name", ""))
        self.shop_in = self.labeled(body, "اسم المشروع / الدكان", "", u.get("shop", ""))
        self.loc_in = self.labeled(body, "موقع الدكان", "", u.get("loc", ""))
        self.phone_in = self.labeled(body, "رقم التاجر", "", u.get("phone", ""),
                                     input_filter="int")

    def on_save(self, *a):
        name = self.name_in.text.strip()
        shop = self.shop_in.text.strip()
        loc = self.loc_in.text.strip()
        phone = self.phone_in.text.strip()
        if len(name.split()) < 2:
            self.msg_dt.text = "أدخل الاسم كاملاً"
            return
        if not shop or not loc:
            self.msg_dt.text = "أدخل اسم المشروع والموقع"
            return
        if len(phone) < 7:
            self.msg_dt.text = "أدخل رقم التاجر بشكل صحيح"
            return
        self.run(lambda: self.app.update_profile_remote(name, shop, loc, phone),
                 lambda: self.app.open_settings(back=True))


class DevicesScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.build_ui()
        self.load()

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header(
            "الأجهزة المتصلة", HEADER,
            on_back=lambda *a: self.app.open_settings(back=True)))
        body = make_body(padding=[dp(12), dp(10), dp(12), dp(10)])
        self.status = mk_text("جاري التحميل...", dp(13), MUTED,
                              halign="center", height=dp(30))
        body.add_widget(self.status)
        scroll, self.list_layout = make_scroll_list(spacing=dp(8))
        body.add_widget(scroll)
        root.add_widget(body)
        self.add_widget(root)

    def load(self):
        self.status.text = "جاري التحميل..."

        def w():
            try:
                email = (self.app.data.get("user") or {}).get("email", "")
                rec, _m = DB.get_user(email)
                devs = (rec or {}).get("dev") or {}
                Clock.schedule_once(lambda dt: self.show(devs), 0)
            except Exception as e:
                msg = str(e)[:60]
                Clock.schedule_once(lambda dt: self.fail(msg), 0)

        threading.Thread(target=w, daemon=True).start()

    def fail(self, msg):
        self.status.text = msg or "تعذر تحميل الأجهزة )تحقق من الانترنت("

    def show(self, devs):
        self.list_layout.clear_widgets()
        me = self.app.data.get("device_id")
        if not devs:
            self.status.text = "لا توجد أجهزة مسجلة، اضغط مزامنة أولاً"
            return
        self.status.text = f"عدد الأجهزة: {len(devs)}"
        items = sorted(devs.items(), key=lambda kv: (kv[1] or {}).get("t", ""),
                       reverse=True)
        for did, info in items:
            info = info or {}
            row = CardBox(orientation="horizontal", size_hint_y=None,
                          height=dp(74), padding=[dp(12), dp(8)],
                          spacing=dp(8))
            if did != me:
                kb = mk_btn("طرد", size_hint=(None, None),
                            size=(dp(64), dp(38)), font_size=dp(14),
                            background_color=RED,
                            pos_hint={"center_y": 0.5})
                kb.bind(on_release=lambda w, d=did, n=info.get("n", "جهاز"):
                        self.confirm_kick(d, n))
                row.add_widget(kb)
            box = BoxLayout(orientation="vertical")
            nm = info.get("n", "جهاز") + ("  )هذا الجهاز(" if did == me else "")
            box.add_widget(mk_text(nm, dp(15), TEXT, hint_y=0.55))
            box.add_widget(mk_text("آخر مزامنة: " + str(info.get("t", ""))[:16],
                                   dp(12), MUTED, hint_y=0.45))
            row.add_widget(box)
            self.list_layout.add_widget(row)

    def confirm_kick(self, did, name):
        content = BoxLayout(orientation="vertical", spacing=dp(10),
                            padding=dp(12))
        content.add_widget(mk_text(f"طرد الجهاز ({name}) من الحساب؟",
                                   dp(15), TEXT, halign="center",
                                   height=dp(44)))
        content.add_widget(mk_text(
            "سيتم تسجيل خروجه عند أول مزامنة. لقفل الحساب عنه نهائياً غيّر كلمة المرور.",
            dp(12), MUTED, halign="center", height=dp(48)))
        content.add_widget(Widget())
        bb = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        yes = mk_btn("طرد", background_color=RED)
        no = mk_btn("إلغاء", background_color=GRAY_BTN)
        bb.add_widget(yes)
        bb.add_widget(no)
        content.add_widget(bb)
        popup = make_arabic_popup("طرد جهاز", content, size_hint=(0.9, 0.46),
                                  title_color=RED, separator_color=RED)

        def do(*a):
            popup.dismiss()
            self.status.text = "جاري الطرد..."

            def w():
                try:
                    ok, err = self.app.kick_device_remote(did)
                except Exception as e:
                    ok, err = False, str(e)[:60]
                Clock.schedule_once(
                    lambda dt: (self.load() if ok else self.fail(err)), 0)

            threading.Thread(target=w, daemon=True).start()

        yes.bind(on_release=do)
        no.bind(on_release=lambda *a: popup.dismiss())
        popup.open()


class AccountsScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.build_ui()

    def _acc_card(self, user, tag, on_switch=None):
        row = CardBox(orientation="horizontal", size_hint_y=None,
                      height=dp(84), padding=[dp(12), dp(8)], spacing=dp(8))
        if on_switch:
            sb = mk_btn("تبديل", size_hint=(None, None),
                        size=(dp(70), dp(38)), font_size=dp(14),
                        background_color=GREEN, pos_hint={"center_y": 0.5})
            sb.bind(on_release=lambda *a: on_switch())
            row.add_widget(sb)
        box = BoxLayout(orientation="vertical")
        title = (user.get("shop") or user.get("name") or user.get("email", ""))
        box.add_widget(mk_text(title + tag, dp(15), TEXT, hint_y=0.4))
        box.add_widget(mk_text(user.get("name", ""), dp(12), MUTED, hint_y=0.3))
        box.add_widget(mk_text(user.get("email", ""), dp(12), MUTED, hint_y=0.3))
        row.add_widget(box)
        return row

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header(
            "الحسابات", HEADER,
            on_back=lambda *a: self.app.open_settings(back=True)))
        body = make_body(padding=[dp(12), dp(10), dp(12), dp(10)])
        scroll, lay = make_scroll_list(spacing=dp(8))
        cur = self.app.data.get("user") or {}
        lay.add_widget(self._acc_card(cur, "  )الحالي("))
        for email, st in (self.app.data.get("accounts") or {}).items():
            u = (st or {}).get("user") or {"email": email}
            lay.add_widget(self._acc_card(
                u, "", on_switch=lambda e=email: self.app.switch_account(e)))
        body.add_widget(scroll)
        body.add_widget(mk_text(
            "التبديل بين الحسابات يعمل بدون انترنت. اضغط مزامنة بعد التبديل لرفع التغييرات.",
            dp(12), MUTED, halign="center", height=dp(40)))
        add = mk_btn("إضافة حساب آخر", height=dp(50), font_size=dp(16),
                     background_color=BLUE)
        add.bind(on_release=lambda *a: self.app.begin_add_account())
        body.add_widget(add)
        root.add_widget(body)
        self.add_widget(root)
