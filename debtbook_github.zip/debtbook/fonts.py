# -*- coding: utf-8 -*-
"""إدارة الخطوط: font.otf الأساسي (يُنزَّل) والخطوط الإضافية."""

import os
import re
from kivy.core.text import Label as CoreLabel, LabelBase
from paths import APP_DIR, DATA_DIR, FONT_STORE
from utils import looks_like_font


PRIMARY_FONT = "font.otf"          # الخط الأساسي: يُنزَّل أول مرة من قناة التحميلات
FALLBACK_ARABIC_OK = False          # هل وجدنا خط نظام عربي لعرض صفحة التحميل؟
FONT_DIR = os.path.join(DATA_DIR, "fonts")


FONT_NAME = "AppFont"


FONT_CANDIDATES = [
    os.path.join(APP_DIR, "font.ttf"),
    os.path.join(APP_DIR, "font.otf"),
    os.path.join(APP_DIR, "font.ttc"),
    os.path.join(APP_DIR, "font.ttf"),
    os.path.join(APP_DIR, "fonts", "font.ttf"),
    os.path.join(APP_DIR, "fonts", "font.otf"),
    os.path.join(APP_DIR, "fonts", "font.ttf"),
    os.path.join(FONT_DIR, "font.ttf"),
    # [إصلاح كراش 3] حُذفت مسارات /sdcard/ نهائياً (تفشل على أندرويد 11+)
    "/system/fonts/NotoNaskhArabic-Regular.ttf",
    "/system/fonts/DroidSansArabic.ttf",
    "/system/fonts/NotoSansArabic-Regular.ttf",
    "/system/fonts/DroidSansFallback.ttf",
    "/system/fonts/DroidNaskh-Regular.ttf",
]


def _scan_dir(d, only_names=None):
    found = []
    if not os.path.isdir(d):
        return found
    try:
        for f in sorted(os.listdir(d)):
            low = f.lower()
            if not low.endswith((".ttf", ".otf", ".ttc")):
                continue
            if only_names and not any(k in low for k in only_names):
                continue
            found.append(os.path.join(d, f))
    except Exception:
        pass
    return found


def _iter_font_candidates():
    seen = set()
    pool = list(FONT_CANDIDATES)
    # [إصلاح كراش 4] نمسح فقط المجلدات الآمنة (مجلد التطبيق)، بدون /sdcard/
    for d in [APP_DIR, os.path.join(APP_DIR, "fonts"), FONT_DIR]:
        pool.extend(_scan_dir(d))
    pool.extend(_scan_dir("/system/fonts",
                          only_names=("arab", "naskh", "kufi", "fallback")))
    for p in pool:
        if p in seen:
            continue
        seen.add(p)
        try:
            if os.path.exists(p) and os.path.getsize(p) > 1000:
                yield p
        except Exception:
            continue


def _font_has_arabic(name):
    try:
        a = CoreLabel(text="\uFEE1\uFEE3\uFEE4\uFEA3", font_size=28, font_name=name)
        a.refresh()
        ta = a.texture
        if ta is None or ta.width < 4:
            return False
    except Exception as e:
        print(f"[FONT TEST ERR] {e}")
        return False
    try:
        b = CoreLabel(text="\U0010FFFD\U0010FFFD\U0010FFFD\U0010FFFD",
                      font_size=28, font_name=name)
        b.refresh()
        tb = b.texture
    except Exception:
        tb = None
    if tb is None:
        return True
    if ta.size != tb.size:
        return True
    try:
        return ta.pixels != tb.pixels
    except Exception:
        return True


FONT_PATH = None


FONT_REGISTERED = False


def init_fallback_font():
    """يبحث عن أول خط عربي صالح (مجلد التطبيق ثم خطوط النظام).
    [إصلاح كراش 6] كل LabelBase.register داخل try/except مع log واضح، فلو فشل
    خط واحد ننتقل للتالي ولا يتوقف التطبيق. وتعمل الدالة فقط لو font.otf
    الأساسي غير موجود (فلا نختبر الخطوط عند كل تشغيل)."""
    global FONT_NAME, FONT_PATH, FONT_REGISTERED
    n = 0
    for p in _iter_font_candidates():
        n += 1
        name = "AppFont%d" % n
        try:
            LabelBase.register(name=name, fn_regular=p)
        except Exception as e:
            print(f"[FONT] register FAILED {p}: {e}")
            continue
        try:
            ok = _font_has_arabic(name)
        except Exception as e:
            print(f"[FONT] glyph test FAILED {p}: {e}")
            continue
        if ok:
            FONT_NAME, FONT_PATH, FONT_REGISTERED = name, p, True
            print(f"[FONT] OK: {p}")
            return True
        print(f"[FONT] no arabic glyphs: {p}")
    print("[FONT] WARN: no usable Arabic font found!")
    return False


def _font_name():
    return FONT_NAME if FONT_REGISTERED else "Roboto"


USER_FONTS = {}        # اسم الملف -> (الاسم المسجّل، المسار)


FONT_NAME_RE = re.compile(r"font\d*\.otf")


def font_sort_key(fn):
    m = re.fullmatch(r"font(\d*)\.otf", fn)
    return int(m.group(1) or 0) if m else 10 ** 6


def font_label(fn):
    m = re.fullmatch(r"font(\d*)\.otf", fn)
    n = int(m.group(1) or 0) if m else 0
    return "الخط الأساسي" if n == 0 else "خط %d" % n


def register_user_fonts():
    """يسجّل font.otf الأساسي وأي خط نُزّل سابقاً (كلها داخل FONT_STORE).
    يجب استدعاؤها من الخيط الرئيسي."""
    cands = {}
    try:
        for f in os.listdir(FONT_STORE):
            p = os.path.join(FONT_STORE, f)
            if (FONT_NAME_RE.fullmatch(f) and os.path.getsize(p) > 1000
                    and looks_like_font(p)):
                cands[f] = p
    except Exception:
        pass
    for fn, p in cands.items():
        if USER_FONTS.get(fn, (None, None))[1] == p:
            continue
        nm = "UF_" + fn.replace(".", "_")
        try:
            LabelBase.register(name=nm, fn_regular=p)
            USER_FONTS[fn] = (nm, p)
        except Exception as e:
            print(f"[FONT] register FAILED for user font {fn} ({p}): {e}")


def set_app_font(fn):
    """يفعّل الخط fn لكل التطبيق (الشاشة + صور الفواتير). يرجع True لو نجح."""
    global FONT_NAME, FONT_PATH, FONT_REGISTERED
    info = USER_FONTS.get(fn)
    if not info:
        return False
    FONT_NAME, FONT_PATH = info
    FONT_REGISTERED = True
    return True


def primary_font_ready():
    """true لو font.otf نُزّل وسُجّل بنجاح."""
    return PRIMARY_FONT in USER_FONTS


def fallback_arabic_ok():
    """هل يوجد خط نظام عربي صالح (يُقرأ وقت التشغيل لأن القيمة تتغير)."""
    return FALLBACK_ARABIC_OK


def current_font_path():
    """مسار الخط المستخدم حالياً (يقرؤه PIL عند رسم الفواتير)."""
    return FONT_PATH


def init_fonts():
    """تُستدعى مرة واحدة من build(). كل خطوة محمية بـ try/except.
    ترجع True لو font.otf جاهز، وإلا تجهّز خط نظام عربي لعرض صفحة التحميل."""
    global FALLBACK_ARABIC_OK
    try:
        register_user_fonts()
    except Exception as e:
        print(f"[FONT] register_user_fonts failed (ignored): {e}")
    if primary_font_ready():
        return True
    try:
        FALLBACK_ARABIC_OK = bool(init_fallback_font())
    except Exception as e:
        print(f"[FONT] fallback init failed (ignored): {e}")
        FALLBACK_ARABIC_OK = False
    return False
