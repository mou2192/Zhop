# -*- coding: utf-8 -*-
"""التطبيق الرئيسي DebtBookApp: التنقل، الدخول، المزامنة، الإعدادات."""

import os
import threading
import traceback
from kivy.animation import Animation
from kivy.app import App
from kivy.base import ExceptionHandler, ExceptionManager
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label as KLabel
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, ScreenManager, SlideTransition
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from components import make_client_row
from crashlog import write_crash
from documents import first_name
from fonts import PRIMARY_FONT, init_fonts, primary_font_ready, set_app_font
from merge import merge_client_data
from paths import CRASH_LOG, DATA_FILE, DOC_DIR
from screen_fonts import FontGateScreen, FontScreen
from screens_auth import LoginScreen, RegisterScreen, TermsScreen
from screens_client import (AddInvoiceScreen, AddReceiptScreen, ClientScreen,
    InvoiceDetailScreen)
from screens_settings import (ACC_KEYS, AccountsScreen, ChangePasswordScreen,
    DevicesScreen, EditProfileScreen, SettingsScreen, SyncScreen)
from storage import load_data, save_data
from telegram_db import DB, TgError, hash_password
from theme import (BG, GLASS, GRAY_BTN, GREEN, HEADER, MUTED, PRIMARY, RED, WHITE,
    apply_theme, is_dark, register_theme)
from utils import gen_id, get_device_name, money_signed, now_full, set_seller
from widgets import (CardBox, DrawnText, _FadeOverlay, make_arabic_popup, make_body,
    make_scroll_list, mk_btn, mk_input, mk_text, refresh_all_texts, schedule_refresh)

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


_KEEP_ALIVE_INSTALLED = False


class _KeepAlive(ExceptionHandler):
    """خطأ في زر أو شاشة لا يُغلق التطبيق: نسجّله ونكمل، ونعرض نصه مرة واحدة."""
    count = 0

    def handle_exception(self, inst):
        if not isinstance(inst, Exception):
            return ExceptionManager.RAISE
        try:
            write_crash("".join(traceback.format_exception(
                type(inst), inst, inst.__traceback__)))
        except Exception:
            pass
        _KeepAlive.count += 1
        if _KeepAlive.count > 300:          # حلقة أخطاء لا تنتهي: نتوقف
            return ExceptionManager.RAISE
        try:
            app = App.get_running_app()
            if app is not None and not getattr(app, "_crash_shown", True):
                Clock.schedule_once(app._show_last_crash, 0.5)
        except Exception:
            pass
        return ExceptionManager.PASS


def _install_keep_alive():
    global _KEEP_ALIVE_INSTALLED
    if not _KEEP_ALIVE_INSTALLED:
        ExceptionManager.add_handler(_KeepAlive())
        _KEEP_ALIVE_INSTALLED = True


class DebtBookApp(App):
    def build(self):
        # أي خطأ هنا لا يغلق التطبيق: نعرض نصه على الشاشة بدل الإغلاق المفاجئ
        try:
            return self._build_root()
        except Exception:
            tb = traceback.format_exc()
            write_crash(tb)
            return self._error_view(tb)

    def _error_view(self, tb):
        box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(8))
        box.add_widget(KLabel(text="Startup error - send a screenshot",
                              color=(1, 0.4, 0.4, 1), size_hint_y=None,
                              height=dp(34)))
        sv = ScrollView()
        lbl = KLabel(text=tb[-3000:], font_size=dp(10), halign="left",
                     valign="top", size_hint_y=None)
        lbl.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))
        lbl.bind(texture_size=lambda w, v: setattr(w, "height", v[1]))
        sv.add_widget(lbl)
        box.add_widget(sv)
        return box

    def _build_root(self):
        _install_keep_alive()
        self.title = "دفتر ديون الزهوب"
        self.data = load_data()
        self._adding = False
        if not self.data.get("device_id"):
            self.data["device_id"] = gen_id()
        # الخط: font.otf الأساسي يُنزَّل أول مرة (FontGateScreen)، وبعدها
        # الخط الذي اختاره المستخدم
        init_fonts()
        if not self.data.get("font"):
            self.data["font"] = PRIMARY_FONT
        if primary_font_ready():
            if not set_app_font(self.data["font"]):
                set_app_font(PRIMARY_FONT)
        set_seller(self.data.get("user"))
        save_data(self.data)
        apply_theme(self.data.get("theme", "light"))
        Window.clearcolor = BG
        try:
            Window.softinput_mode = "below_target"
        except Exception:
            pass

        self.search_query = ""
        self._seq = 0
        self._cur_client = 0
        self._crash_shown = False

        self.sm = ScreenManager(transition=SlideTransition(duration=0.18))
        self.sm.add_widget(Screen(name="boot"))

        Window.bind(on_keyboard=self._on_back_key)
        Window.bind(size=lambda *a: schedule_refresh(0.1))
        self.sm.transition.bind(on_complete=lambda *a: schedule_refresh(0.02))
        self.sm.bind(current=lambda *a: schedule_refresh(0.25))

        self.sm.current = "boot"
        # أي شيء إضافي (عرض سجل الأعطال السابق) يتم بعد بدء التطبيق
        Clock.schedule_once(self._show_last_crash, 1.5)
        Clock.schedule_once(self._start, 0.1)
        return self.sm

    # ==========================================================
    # البداية: صفحة تحميل الخط (لو لزم) ثم الدخول
    # ==========================================================
    def _start(self, dt=None):
        try:
            if primary_font_ready():
                self._continue_after_font()
            else:
                self.show_font_gate()
        except Exception:
            write_crash(traceback.format_exc())
            raise

    def show_font_gate(self):
        for s in list(self.sm.screens):
            if s.name == "gate":
                self.sm.remove_widget(s)
        self.sm.add_widget(FontGateScreen(self, name="gate"))
        self.sm.transition.direction = "left"
        self.sm.current = "gate"

    def font_ready(self):
        """يُستدعى بعد نجاح تحميل font.otf."""
        fn = self.data.get("font") or PRIMARY_FONT
        if not set_app_font(fn):
            set_app_font(PRIMARY_FONT)
        refresh_all_texts()
        self._continue_after_font()

    def _continue_after_font(self):
        # جلسة واحدة: لو فيه مستخدم محفوظ نفتح الرئيسية مباشرة
        if (self.data.get("user") or {}).get("email"):
            self._build_main_and_show()
        else:
            self.go_login()

    def _show_last_crash(self, dt=None):
        """لو توقف التطبيق في المرة السابقة بخطأ، نعرض نصه ليسهل إصلاحه."""
        try:
            if not os.path.exists(CRASH_LOG):
                return
            with open(CRASH_LOG, "r", encoding="utf-8") as f:
                txt = f.read()[-1500:]
            os.remove(CRASH_LOG)
            if not txt.strip():
                return
            self._crash_shown = True
            box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(10))
            box.add_widget(mk_text("سجل آخر خطأ )صوّره وأرسله للمطوّر(:", dp(14),
                                   RED, halign="center", height=dp(30)))
            lbl = KLabel(text=txt, color=(0.3, 0.3, 0.3, 1), font_size=dp(10),
                         halign="left", valign="top")
            lbl.bind(size=lambda w, v: setattr(w, "text_size", (v[0], None)))
            box.add_widget(lbl)
            ok = mk_btn("حسناً", height=dp(46), background_color=GRAY_BTN)
            box.add_widget(ok)
            pop = make_arabic_popup("تقرير خطأ", box, size_hint=(0.95, 0.7),
                                    title_color=RED, separator_color=RED)
            ok.bind(on_release=lambda *a: pop.dismiss())
            pop.open()
        except Exception as e:
            print(f"[CRASHLOG] {e}")

    # ==========================================================
    # تسجيل / دخول (يعمل من أي جهاز، بدون getUpdates)
    # ==========================================================
    def _dev_id(self):
        if not self.data.get("device_id"):
            self.data["device_id"] = gen_id()
        return self.data["device_id"]

    def do_register(self, name, email, password, shop="", loc="", phone=""):
        try:
            rec, mid = DB.create_user(email, name, password, shop, loc, phone,
                                      self._dev_id(), get_device_name())
            self.data.setdefault("_tg_meta", {})["users_message_id"] = mid
            return True, "OK"
        except TgError as e:
            return False, str(e)
        except Exception as e:
            return False, str(e)[:50]

    def verify_login(self, email, password):
        try:
            rec, mid = DB.get_user(email)
            if not rec:
                return False, "البريد غير مسجل"
            if not DB.check_password(rec, password):
                return False, "كلمة المرور خاطئة"
            devs = dict(rec.get("dev") or {})
            devs[self._dev_id()] = {"n": get_device_name(), "t": now_full()}
            rec["dev"] = devs
            rec.setdefault("sv", 1)
            mid = DB.save_user(rec, mid)
            server, _texts = DB.read_clients(rec)
            return True, {"rec": rec, "mid": mid, "server": server}
        except TgError as e:
            return False, str(e)
        except Exception as e:
            return False, str(e)[:50]

    def _claim_device(self, email):
        """لو الجهاز كان لحساب آخر نبدأ ببيانات فاضية (لا نخلط الحسابات)."""
        owner = self.data.get("owner")
        if owner and owner != email:
            self.data["clients"] = []
            self.data["_deleted"] = []
            self.data["_tg_meta"] = {}
        self.data["owner"] = email

    # ---------- تعدد الحسابات على الجهاز ----------
    def stash_current(self):
        email = (self.data.get("user") or {}).get("email")
        if not email:
            return
        self.data.setdefault("accounts", {})[email] = {
            k: self.data.get(k) for k in ACC_KEYS}

    def _load_account_state(self, st):
        defaults = {"clients": [], "_deleted": [], "_tg_meta": {}}
        for k in ACC_KEYS:
            v = (st or {}).get(k)
            self.data[k] = v if v is not None else defaults.get(k)

    def _prepare_account_switch(self, email):
        cur = (self.data.get("user") or {}).get("email")
        if self._adding and cur and cur != email:
            self.stash_current()
            accs = self.data.setdefault("accounts", {})
            if email in accs:
                self._load_account_state(accs.pop(email))
            else:
                self._load_account_state({})
        self._adding = False

    def switch_account(self, email):
        accs = self.data.setdefault("accounts", {})
        if email not in accs:
            return
        self.stash_current()
        self._load_account_state(accs.pop(email))
        set_seller(self.data.get("user"))
        self.save()
        self._build_main_and_show()

    def begin_add_account(self):
        self._adding = True
        self.go_login()

    def cancel_add_account(self):
        self._adding = False
        self.go_main()

    @staticmethod
    def _user_from_rec(rec):
        return {"email": rec.get("email", ""), "name": rec.get("name", ""),
                "shop": rec.get("shop", ""), "loc": rec.get("loc", ""),
                "phone": rec.get("phone", "")}

    def on_register_success(self, email, name, shop="", loc="", phone=""):
        self._prepare_account_switch(email)
        self._claim_device(email)
        self.data["user"] = {"email": email, "name": name, "shop": shop,
                             "loc": loc, "phone": phone}
        self.data["_sv"] = 1
        self.data["_dev_ok"] = True
        set_seller(self.data["user"])
        self.save()
        self._build_main_and_show()

    def on_login_success(self, info):
        rec = info["rec"]
        email = rec.get("email", "")
        self._prepare_account_switch(email)
        self._claim_device(email)
        self.data["user"] = self._user_from_rec(rec)
        self.data["_sv"] = rec.get("sv", 1)
        self.data["_dev_ok"] = True
        set_seller(self.data["user"])
        meta = self.data.setdefault("_tg_meta", {})
        meta["users_message_id"] = info["mid"]
        try:
            server = info.get("server") or {}
            legacy = rec.get("_legacy_clients")
            if legacy:                       # بيانات من النظام القديم
                lc, _d = merge_client_data(server, legacy.get("clients", []), [])
                server = {"clients": lc, "deleted": server.get("deleted", [])}
                meta["legacy_clients_mid"] = rec.get("_legacy_clients_mid")
            clients, deleted = merge_client_data(
                server, self.data.get("clients", []),
                self.data.get("_deleted", []))
            self.data["clients"] = clients
            self.data["_deleted"] = deleted
        except Exception as e:
            print(f"[LOGIN SYNC] {e}")
        self.save()
        self._build_main_and_show()

    # ==========================================================
    # المزامنة
    # ==========================================================
    def do_sync(self, *a):
        sync_screen = SyncScreen(self)
        self._show(sync_screen, "left")

        def status(main, sub=""):
            Clock.schedule_once(lambda dt: sync_screen.set_status(main, sub), 0)

        def worker():
            try:
                email = (self.data.get("user") or {}).get("email")
                if not email:
                    status("خطأ", "غير مسجل")
                    return
                status("جاري المزامنة...")
                rec, mid = DB.get_user(email)
                if not rec:
                    status("الحساب غير موجود على الانترنت",
                           "ربما حُذف من جهاز آخر")
                    return
                err = self._session_error(rec)
                if err:
                    status("تم إنهاء الجلسة", err.replace("\n", " - "))
                    Clock.schedule_once(lambda dt: self.force_logout(err), 2.5)
                    return
                devs = dict(rec.get("dev") or {})
                devs[self._dev_id()] = {"n": get_device_name(), "t": now_full()}
                rec["dev"] = devs
                rec.setdefault("sv", 1)
                mid = DB.save_user(rec, mid)
                self.data["_dev_ok"] = True
                self.data["_sv"] = rec["sv"]
                self._apply_profile(rec)
                server, texts = DB.read_clients(rec)

                status("جاري الدمج...")
                clients, deleted = merge_client_data(
                    server, self.data.get("clients", []),
                    self.data.get("_deleted", []))

                status("جاري الرفع...")
                rec2 = DB.write_clients(
                    rec, mid, {"clients": clients, "deleted": deleted}, texts)

                meta = self.data.setdefault("_tg_meta", {})
                meta["users_message_id"] = mid
                meta["clients_message_ids"] = rec2.get("cl", [])
                old = meta.pop("legacy_clients_mid", None)
                if old:
                    DB.delete(DB.clients_ch, old)

                self.data["clients"] = clients
                self.data["_deleted"] = deleted
                self.save()

                status("تمت المزامنة بنجاح ✅", f"{len(clients)} عميل")
                Clock.schedule_once(lambda dt: self._after_sync(), 1.5)
            except TgError as e:
                print(f"[SYNC] {e}")
                status("فشلت المزامنة", str(e)[:60])
            except Exception as e:
                print(f"[SYNC] {e}")
                status("فشلت المزامنة", str(e)[:60])

        threading.Thread(target=worker, daemon=True).start()

    def _after_sync(self):
        self._build_main_and_show()

    # ==========================================================
    # الجلسات والأجهزة وبيانات البائع
    # ==========================================================
    def _session_error(self, rec):
        """يرجع نص الخطأ لو يجب إخراج هذا الجهاز، وإلا None."""
        try:
            sv = int(rec.get("sv", 1) or 1)
        except Exception:
            sv = 1
        local = self.data.get("_sv")
        if local is not None and sv != local:
            return ("لا يمكنك المزامنة\nتم تغيير كلمة المرور من الجهاز (%s)"
                    % (rec.get("pwdev") or "جهاز آخر"))
        devs = rec.get("dev")
        if (self.data.get("_dev_ok") and isinstance(devs, dict)
                and self._dev_id() not in devs):
            return "تم إخراج هذا الجهاز من الحساب\nسجّل الدخول من جديد"
        return None

    def _apply_profile(self, rec):
        u = dict(self.data.get("user") or {})
        new = self._user_from_rec(rec)
        new["email"] = u.get("email") or new["email"]
        if new != u:
            self.data["user"] = new
            set_seller(new)
            return True
        set_seller(u)
        return False

    def force_logout(self, msg):
        self.do_logout()
        try:
            scr = self.sm.get_screen("login")
            scr.msg_dt.height = dp(70)
            scr.msg_dt.text = msg
        except Exception as e:
            print(f"[FORCE LOGOUT] {e}")

    def _fresh_rec(self):
        """(ينفَّذ في خيط) يرجع (rec, mid, error)."""
        email = (self.data.get("user") or {}).get("email", "")
        rec, mid = DB.get_user(email)
        if not rec:
            return None, None, "الحساب غير موجود على الانترنت"
        err = self._session_error(rec)
        if err:
            return None, None, err.replace("\n", " - ")
        return rec, mid, None

    def change_password_remote(self, old, new):
        rec, mid, err = self._fresh_rec()
        if err:
            return False, err
        if not DB.check_password(rec, old):
            return False, "كلمة المرور الحالية خاطئة"
        me = self._dev_id()
        rec["pw"] = hash_password(new)
        rec.pop("password", None)
        rec["sv"] = int(rec.get("sv", 1) or 1) + 1
        rec["pwdev"] = get_device_name()
        rec["dev"] = {me: {"n": get_device_name(), "t": now_full()}}
        DB.save_user(rec, mid)
        self.data["_sv"] = rec["sv"]
        self.data["_dev_ok"] = True
        self.save()
        return True, ""

    def update_profile_remote(self, name, shop, loc, phone):
        rec, mid, err = self._fresh_rec()
        if err:
            return False, err
        rec["name"], rec["shop"], rec["loc"], rec["phone"] = name, shop, loc, phone
        DB.save_user(rec, mid)
        u = dict(self.data.get("user") or {})
        u.update({"name": name, "shop": shop, "loc": loc, "phone": phone})
        self.data["user"] = u
        set_seller(u)
        self.save()
        return True, ""

    def kick_device_remote(self, dev_id):
        rec, mid, err = self._fresh_rec()
        if err:
            return False, err
        devs = dict(rec.get("dev") or {})
        devs.pop(dev_id, None)
        rec["dev"] = devs
        DB.save_user(rec, mid)
        return True, ""

    def set_font(self, fn):
        if set_app_font(fn):
            self.data["font"] = fn
            self.save()
            refresh_all_texts()

    # ==========================================================
    # الشاشة الرئيسية
    # ==========================================================
    def _build_main_and_show(self):
        for s in list(self.sm.screens):
            if s.name == "main":
                self.sm.remove_widget(s)
        main_screen = Screen(name="main")
        self.main_screen = main_screen
        main_screen.add_widget(self._build_main())
        self.sm.add_widget(main_screen)
        self.sm.transition.direction = "left"
        self.sm.current = "main"
        self.refresh_clients()
        Clock.schedule_once(self._cleanup, 0.5)

    def _build_main(self):
        root = BoxLayout(orientation="vertical", spacing=0)

        sync_btn = mk_btn("مزامنة", size_hint=(None, None),
                          size=(dp(76), dp(38)), font_size=dp(14),
                          background_color=GLASS)
        sync_btn.bind(on_release=self.do_sync)

        settings_btn = mk_btn("إعدادات", size_hint=(None, None),
                              size=(dp(76), dp(38)), font_size=dp(14),
                              background_color=GLASS)
        settings_btn.bind(on_release=self.open_settings)

        head = FloatLayout(size_hint_y=None, height=dp(60))
        with head.canvas.before:
            Color(*HEADER)
            hr = RoundedRectangle(pos=head.pos, size=head.size,
                                  radius=[0, 0, dp(20), dp(20)])

        def _uh(*a):
            hr.pos = head.pos
            hr.size = head.size
        head.bind(pos=_uh, size=_uh)

        user_name = (self.data.get("user") or {}).get("name", "")
        title = DrawnText(text=f"مرحباً {first_name(user_name)[:12]}",
                          font_size=dp(17), color=WHITE, halign="center",
                          size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
        title.disabled = True
        head.add_widget(title)

        sync_btn.pos_hint = {"right": 0.98, "center_y": 0.5}
        head.add_widget(sync_btn)
        settings_btn.pos_hint = {"x": 0.02, "center_y": 0.5}
        head.add_widget(settings_btn)
        root.add_widget(head)

        body = make_body(padding=[dp(12), dp(8), dp(12), dp(10)])
        stats = BoxLayout(size_hint_y=None, height=dp(72), spacing=dp(10))
        debt_card = CardBox(orientation="vertical", padding=[dp(10), dp(8)])
        debt_card.add_widget(mk_text("إجمالي الديون", dp(12), MUTED,
                                     halign="center", hint_y=0.4))
        self.stat_debt = mk_text("0 ريال", dp(18), RED, halign="center",
                                 hint_y=0.6)
        debt_card.add_widget(self.stat_debt)
        count_card = CardBox(orientation="vertical", padding=[dp(10), dp(8)])
        count_card.add_widget(mk_text("عدد العملاء", dp(12), MUTED,
                                      halign="center", hint_y=0.4))
        self.stat_count = mk_text("0", dp(18), PRIMARY, halign="center",
                                  hint_y=0.6)
        count_card.add_widget(self.stat_count)
        stats.add_widget(debt_card)
        stats.add_widget(count_card)
        body.add_widget(stats)

        self.search_input = mk_input(hint_text="ابحث باسم العميل أو رقمه...",
                                     size_hint_y=None, height=dp(48))
        self.search_input.bind(text=self.on_search)
        body.add_widget(self.search_input)

        add_btn = mk_btn("+ إضافة عميل جديد", height=dp(50),
                         font_size=dp(16), background_color=GREEN)
        add_btn.bind(on_release=self.open_add_client_popup)
        body.add_widget(add_btn)

        scroll, self.clients_layout = make_scroll_list(spacing=dp(8))
        body.add_widget(scroll)
        root.add_widget(body)
        return root

    # ==========================================================
    # الإعدادات / الثيم / الخروج / حذف الحساب
    # ==========================================================
    def open_settings(self, *a, back=False):
        self._show(SettingsScreen(self), "right" if back else "left")

    def open_edit_profile(self, *a):
        self._show(EditProfileScreen(self), "left")

    def open_change_password(self, *a):
        self._show(ChangePasswordScreen(self), "left")

    def open_devices(self, *a):
        self._show(DevicesScreen(self), "left")

    def open_accounts(self, *a):
        self._show(AccountsScreen(self), "left")

    def open_fonts(self, *a):
        self._show(FontScreen(self), "left")

    def open_terms(self):
        for s in list(self.sm.screens):
            if s.name == "terms":
                self.sm.remove_widget(s)
        ts = TermsScreen(self, name="terms")
        self.sm.transition.direction = "left"
        self.sm.add_widget(ts)
        self.sm.current = "terms"

    def terms_back(self):
        self._back_to_register(False)

    def terms_agreed(self):
        self._back_to_register(True)

    def _back_to_register(self, agreed):
        try:
            reg = self.sm.get_screen("register")
        except Exception:
            self.go_register()
            return
        if agreed:
            reg.set_agreed()
        self.sm.transition.direction = "right"
        self.sm.current = "register"
        Clock.schedule_once(self._cleanup, 0.5)

    def toggle_theme(self, *a):
        new = "light" if is_dark() else "dark"
        ov = None
        try:
            ov = _FadeOverlay(BG)
            Window.add_widget(ov)
        except Exception as e:
            print(f"[THEME] overlay: {e}")
            ov = None
        apply_theme(new)
        self.data["theme"] = new
        self.save()
        q = self.search_query
        self.main_screen.clear_widgets()
        self.main_screen.add_widget(self._build_main())
        if q:
            self.search_input.text = q
        self.refresh_clients()
        cur = self.sm.current_screen
        if isinstance(cur, SettingsScreen):
            cur.clear_widgets()
            cur.build_ui()
        schedule_refresh(0.1)
        if ov is not None:
            Animation(opacity=0, duration=0.45, t="out_quad").start(ov)
            Clock.schedule_once(lambda dt: Window.remove_widget(ov), 0.5)

    def do_logout(self, *a):
        """يرجع لشاشة الدخول والبيانات تبقى على الجهاز."""
        self.data["user"] = None
        set_seller({})
        self.save()
        for s in list(self.sm.screens):
            if s.name == "main":
                self.sm.remove_widget(s)
        self.go_login()

    def delete_account_remote(self, password):
        """(يعمل في خيط) يتحقق من كلمة المرور ويمسح كل رسائل المستخدم من
        القناتين. يرجع (ok, error)."""
        try:
            email = (self.data.get("user") or {}).get("email", "")
            rec, mid = DB.get_user(email)
            if rec is None:
                return True, ""          # محذوف مسبقاً من تليجرام
            if not DB.check_password(rec, password):
                return False, "كلمة المرور خاطئة"
            DB.delete_account(rec, mid)
            for key in ("_legacy_clients_mid",):
                if rec.get(key):
                    DB.delete(DB.clients_ch, rec[key])
            return True, ""
        except TgError as e:
            return False, str(e)
        except Exception as e:
            return False, str(e)[:60]

    def wipe_local_and_restart(self):
        """يحذف data.json بالكامل ويرجع التطبيق كأنه أول مرة."""
        keep = {k: self.data.get(k) for k in
                ("accounts", "device_id", "font", "theme", "dl")
                if self.data.get(k) is not None}
        for p in (DATA_FILE, DATA_FILE + ".tmp"):
            try:
                if os.path.exists(p):
                    os.remove(p)
            except Exception as e:
                print(f"[WIPE] {e}")
        try:
            if os.path.isdir(DOC_DIR):
                for fn in os.listdir(DOC_DIR):
                    os.remove(os.path.join(DOC_DIR, fn))
        except Exception:
            pass
        self.data = load_data()
        self.data.update(keep)
        set_seller({})
        self.save()
        apply_theme(self.data.get("theme", "light"))
        Window.clearcolor = BG
        self.search_query = ""
        for s in list(self.sm.screens):
            if s.name == "main":
                self.sm.remove_widget(s)
        self.go_login()

    # ==========================================================
    # تنقلات
    # ==========================================================
    def go_login(self):
        for s in list(self.sm.screens):
            if s.name == "login":
                self.sm.remove_widget(s)
        ls = LoginScreen(self, name="login")
        self.sm.add_widget(ls)
        self.sm.transition.direction = "right"
        self.sm.current = "login"
        Clock.schedule_once(self._cleanup, 0.5)

    def go_register(self):
        for s in list(self.sm.screens):
            if s.name in ("register", "terms"):
                self.sm.remove_widget(s)
        rs = RegisterScreen(self, name="register")
        self.sm.transition.direction = "left"
        self.sm.add_widget(rs)
        self.sm.current = "register"
        Clock.schedule_once(self._cleanup, 0.5)

    def _cleanup(self, dt=None):
        if self.sm.transition.is_active:
            Clock.schedule_once(self._cleanup, 0.2)
            return
        cur = self.sm.current
        keep = {"login", "register", "main", cur}
        for s in list(self.sm.screens):
            if s.name not in keep:
                try:
                    self.sm.remove_widget(s)
                except Exception:
                    pass

    def _show(self, screen, direction):
        self._seq += 1
        screen.name = "t%d" % self._seq
        self.sm.transition.direction = direction
        self.sm.add_widget(screen)
        self.sm.current = screen.name
        Clock.schedule_once(self._cleanup, 0.5)

    def go_main(self):
        self.refresh_clients()
        self.sm.transition.direction = "right"
        self.sm.current = "main"
        Clock.schedule_once(self._cleanup, 0.5)

    def go_client(self, client_index, back=False):
        self._cur_client = client_index
        self._show(ClientScreen(self, client_index),
                   "right" if back else "left")

    def open_client_screen(self, client_index):
        self.go_client(client_index)

    def open_add_invoice_screen(self, client_index):
        self._show(AddInvoiceScreen(self, client_index), "left")

    def open_add_receipt_screen(self, client_index):
        self._show(AddReceiptScreen(self, client_index), "left")

    def open_invoice_screen(self, client_index, invoice_index):
        self._show(InvoiceDetailScreen(self, client_index, invoice_index),
                   "left")

    def _on_back_key(self, window, key, *args):
        if key != 27:
            return False
        for w in list(Window.children):
            if isinstance(w, Popup):
                w.dismiss()
                schedule_refresh(0.3)
                return True
        cur = self.sm.current_screen
        if cur is None:
            return False
        if cur.name in ("boot", "gate"):
            return False
        if cur.name == "terms":
            self.terms_back()
            return True
        if cur.name == "register":
            self.go_login()
            return True
        if cur.name == "login":
            if self._adding:
                self.cancel_add_account()
                return True
            return False
        if cur.name == "main":
            return False
        if isinstance(cur, (ChangePasswordScreen, EditProfileScreen,
                            DevicesScreen, FontScreen, AccountsScreen)):
            self.open_settings(back=True)
        elif isinstance(cur, (ClientScreen, SyncScreen, SettingsScreen)):
            self.go_main()
        else:
            self.go_client(self._cur_client, back=True)
        return True

    # ==========================================================
    # أدوات
    # ==========================================================
    def save(self):
        save_data(self.data)

    def update_stats(self):
        clients = self.data.get("clients", [])
        total = sum(c.get("balance", 0) for c in clients)
        if hasattr(self, "stat_debt"):
            self.stat_debt.text = f"{money_signed(total)} ريال"
        if hasattr(self, "stat_count"):
            self.stat_count.text = str(len(clients))

    def on_search(self, instance, value):
        self.search_query = value.strip().lower()
        self.refresh_clients()

    def refresh_clients(self):
        if not hasattr(self, "clients_layout"):
            return
        self.clients_layout.clear_widgets()
        clients = self.data.get("clients", [])
        self.update_stats()
        if self.search_query:
            indexed = [(i, c) for i, c in enumerate(clients)
                       if self.search_query in c.get("name", "").lower()
                       or self.search_query in c.get("phone", "").lower()]
        else:
            indexed = list(enumerate(clients))
        if not indexed:
            msg = "لا توجد نتائج" if self.search_query else "لا يوجد عملاء بعد"
            sub = "جرّب اسماً آخر" if self.search_query else "اضغط على إضافة عميل جديد"
            empty = BoxLayout(orientation="vertical", size_hint_y=None,
                              height=dp(90))
            empty.add_widget(mk_text(msg, dp(16), MUTED, halign="center",
                                     hint_y=0.5))
            empty.add_widget(mk_text(sub, dp(13), MUTED, halign="center",
                                     hint_y=0.5))
            self.clients_layout.add_widget(empty)
            schedule_refresh(0.1)
            return
        for real_idx, client in indexed:
            self.clients_layout.add_widget(make_client_row(
                client,
                on_tap=lambda i=real_idx: self.open_client_screen(i)))
        schedule_refresh(0.1)

    def open_add_client_popup(self, *args):
        content = BoxLayout(orientation="vertical", spacing=dp(6),
                            padding=dp(10))
        content.add_widget(mk_text("اسم العميل", dp(13), MUTED,
                                   height=dp(22)))
        name_input = mk_input(size_hint_y=None, height=dp(48),
                              hint_text="الاسم الكامل")
        content.add_widget(name_input)
        content.add_widget(mk_text("رقم الواتساب", dp(13), MUTED,
                                   height=dp(22)))
        phone_input = mk_input(input_filter="int", size_hint_y=None,
                               height=dp(48), hint_text="0771234567")
        content.add_widget(phone_input)
        content.add_widget(Widget())
        btns = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(8))
        save_btn = mk_btn("حفظ", background_color=GREEN)
        cancel_btn = mk_btn("إلغاء", background_color=GRAY_BTN)
        btns.add_widget(save_btn)
        btns.add_widget(cancel_btn)
        content.add_widget(btns)
        popup = make_arabic_popup("إضافة عميل جديد", content,
                                  size_hint=(0.92, 0.55))

        def do_save(*a):
            name = name_input.text.strip()
            if not name:
                return
            self.data.setdefault("clients", []).append({
                "id": gen_id(),
                "name": name,
                "phone": phone_input.text.strip(),
                "balance": 0,
                "invoices": [],
                "mod": now_full(),
            })
            self.save()
            self.refresh_clients()
            popup.dismiss()

        save_btn.bind(on_release=do_save)
        cancel_btn.bind(on_release=lambda *a: popup.dismiss())
        popup.open()
