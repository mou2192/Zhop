# -*- coding: utf-8 -*-
"""شاشات الخطوط: صفحة تحميل الخط الأولى + تغيير الخط من الإعدادات."""

import os
import threading
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import Screen
from kivy.uix.widget import Widget
from fonts import (FONT_NAME_RE, PRIMARY_FONT, USER_FONTS, fallback_arabic_ok,
    font_label, font_sort_key, primary_font_ready, register_user_fonts)
from paths import FONT_STORE
from telegram_db import TgError, TgGone, download_font, find_download, scan_downloads
from theme import BLUE, GREEN, HEADER, MUTED, PRIMARY, SOFT_BLUE, TEXT, register_theme
from widgets import (CardBox, DrawnText, make_body, make_header, make_scroll_list,
    mk_btn, mk_text, schedule_refresh)

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


class FontGateScreen(Screen):
    """أول ما يفتح المستخدم التطبيق ولم يُنزَّل font.otf بعد:
    صفحة فيها زر واحد (تحميل الخط). بعد نجاح التحميل نكمل لصفحة الدخول."""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.busy = False
        self.build_ui()

    @staticmethod
    def _t(arabic, english):
        # قبل تنزيل الخط قد لا يتوفر خط عربي في الجهاز، فنعرض الإنجليزية
        return arabic if fallback_arabic_ok() else english

    def build_ui(self):
        root = BoxLayout(orientation="vertical", padding=[dp(24), dp(24)],
                         spacing=dp(14))
        root.add_widget(Widget())
        root.add_widget(mk_text(
            self._t("تحميل الخط قبل البدء", "Download the font to start"),
            dp(22), PRIMARY, halign="center", height=dp(46)))
        root.add_widget(mk_text(
            self._t("يحتاج التطبيق إلى خط خاص لعرض الكتابة بشكل صحيح",
                    "The app needs a special font to display text correctly"),
            dp(13), MUTED, halign="center", height=dp(30)))
        root.add_widget(mk_text(
            self._t("يتم التحميل مرة واحدة فقط", "Downloaded only once"),
            dp(13), MUTED, halign="center", height=dp(30)))
        self.status = mk_text("", dp(14), TEXT, halign="center", height=dp(40))
        root.add_widget(self.status)
        self.btn = mk_btn(self._t("تحميل الخط", "Download font"),
                          height=dp(54), font_size=dp(18),
                          background_color=GREEN)
        self.btn.bind(on_release=self.start)
        root.add_widget(self.btn)
        root.add_widget(Widget())
        self.add_widget(root)

    def _set_status(self, text, color=None):
        self.status.text = text

    def _set_button(self, text, disabled):
        self.btn.text = text
        self.btn.disabled = disabled

    # ---------- الضغط على الزر ----------
    def start(self, *a):
        if self.busy:
            return
        self.busy = True
        self._set_button(self._t("جاري التحميل...", "Downloading..."), True)
        self._set_status(self._t("جاري البحث عن الخط...", "Looking for the font..."))
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        err = None
        try:
            self._fetch()
        except TgError as e:
            err = str(e)
        except Exception as e:
            print(f"[GATE] {e}")
            err = ""
        Clock.schedule_once(lambda dt: self._done(err), 0)

    def _progress(self, mid):
        Clock.schedule_once(lambda dt: self._set_status(
            self._t("جاري البحث عن الخط...", "Looking for the font...")), 0)

    def _fetch(self):
        """(يعمل في خيط) يجد font.otf في قناة التحميلات وينزّله."""
        cat = self.app.data.setdefault("dl", {})
        item = find_download(cat, PRIMARY_FONT, on_progress=self._progress)
        if not item:
            raise TgError("الخط غير موجود في قناة التحميلات")
        Clock.schedule_once(lambda dt: self._set_status(
            self._t("جاري تحميل الخط...", "Downloading the font...")), 0)
        try:
            download_font(PRIMARY_FONT, item)
        except TgGone:
            # الملف تغيّر مكانه في القناة: نمسح الفهرس المحفوظ ونبحث من جديد
            cat.setdefault("items", {}).pop(PRIMARY_FONT, None)
            cat["last"] = 0
            item = find_download(cat, PRIMARY_FONT, on_progress=self._progress)
            if not item:
                raise TgError("الخط غير موجود في قناة التحميلات")
            download_font(PRIMARY_FONT, item)
        self.app.save()

    def _fail(self, msg):
        self.busy = False
        self._set_status(msg)
        self._set_button(self._t("إعادة المحاولة", "Try again"), False)

    def _done(self, err):
        """(يعمل في الخيط الرئيسي)"""
        if err is not None:
            if fallback_arabic_ok() and err:
                self._fail(err)
            else:
                self._fail("Failed. Check the internet and try again.")
            return
        register_user_fonts()
        if not primary_font_ready():
            try:
                os.remove(os.path.join(FONT_STORE, PRIMARY_FONT))
            except Exception:
                pass
            self._fail(self._t("الخط المحمَّل تالف، حاول مرة أخرى",
                               "The downloaded font is damaged. Try again."))
            return
        self._set_status(self._t("تم تحميل الخط بنجاح", "Font downloaded"))
        Clock.schedule_once(lambda dt: self.app.font_ready(), 0.6)


class FontScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.status_text = ""
        self.scanning = False
        self.downloading = None
        self.build_ui()
        self.refresh_catalog()

    def _names(self):
        items = (self.app.data.get("dl") or {}).get("items", {})
        names = set(USER_FONTS) | {n for n in items if FONT_NAME_RE.fullmatch(n)}
        return sorted(names, key=font_sort_key)

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header(
            "تغيير الخط", HEADER,
            on_back=lambda *a: self.app.open_settings(back=True)))
        body = make_body(padding=[dp(12), dp(10), dp(12), dp(10)])
        self.status = mk_text(self.status_text, dp(13), MUTED,
                              halign="center", height=dp(28))
        body.add_widget(self.status)
        scroll, lay = make_scroll_list(spacing=dp(8))
        cur = self.app.data.get("font") or "font.otf"
        items = (self.app.data.get("dl") or {}).get("items", {})
        for fn in self._names():
            info = USER_FONTS.get(fn)
            if info:                       # مثبّت: عرض الاسم بنفس الخط
                sel = (fn == cur)
                row = CardBox(orientation="vertical", size_hint_y=None,
                              height=dp(84), padding=[dp(12), dp(6)],
                              bg=(SOFT_BLUE if sel else None),
                              on_tap=lambda f=fn: self.pick(f))
                sample = DrawnText(text="دفتر ديون الزهوب", font_size=dp(22),
                                   color=TEXT, halign="center",
                                   size_hint_y=0.62, font_override=info[0])
                sample.disabled = True
                row.add_widget(sample)
                label = font_label(fn) + ("  -  المستخدم حالياً" if sel else "")
                row.add_widget(mk_text(label, dp(12),
                                       PRIMARY if sel else MUTED,
                                       halign="center", hint_y=0.38))
            else:                          # غير منزَّل بعد
                row = CardBox(orientation="horizontal", size_hint_y=None,
                              height=dp(74), padding=[dp(12), dp(8)],
                              spacing=dp(8))
                busy = (self.downloading == fn)
                if not busy:
                    btn = mk_btn("تحميل", size_hint=(None, None),
                                 size=(dp(80), dp(38)), font_size=dp(14),
                                 background_color=GREEN,
                                 pos_hint={"center_y": 0.5})
                    btn.bind(on_release=lambda w, f=fn: self.download(f))
                    row.add_widget(btn)
                box = BoxLayout(orientation="vertical")
                kb = max(1, int((items.get(fn) or {}).get("size", 0) / 1024))
                box.add_widget(mk_text(font_label(fn), dp(16), TEXT,
                                       hint_y=0.55))
                box.add_widget(mk_text(
                    "جاري التحميل..." if busy else f"الحجم: {kb} KB",
                    dp(12), MUTED, hint_y=0.45))
                row.add_widget(box)
            lay.add_widget(row)
        body.add_widget(scroll)
        upd = mk_btn("تحديث القائمة", height=dp(46), font_size=dp(15),
                     background_color=BLUE)
        upd.bind(on_release=lambda *a: self.refresh_catalog())
        body.add_widget(upd)
        root.add_widget(body)
        self.add_widget(root)

    def _rebuild(self):
        self.clear_widgets()
        self.build_ui()
        schedule_refresh(0.05)

    def refresh_catalog(self):
        if self.scanning:
            return
        self.scanning = True
        self.status.text = "جاري البحث عن الخطوط المتاحة..."

        def w():
            err = None
            try:
                cat = self.app.data.setdefault("dl", {})
                scan_downloads(cat)
                self.app.save()
            except TgError as e:
                err = str(e)
            except Exception:
                err = "تعذر الاتصال، تحقق من الانترنت"
            Clock.schedule_once(lambda dt: self._after_scan(err), 0)

        threading.Thread(target=w, daemon=True).start()

    def _after_scan(self, err):
        self.scanning = False
        if err:
            self.status_text = err
        else:
            new = [n for n in self._names() if n not in USER_FONTS]
            self.status_text = (f"تتوفر {len(new)} خطوط للتحميل" if new
                                else "لا توجد خطوط جديدة للتحميل")
        self._rebuild()

    def download(self, fn):
        if self.downloading:
            return
        item = ((self.app.data.get("dl") or {}).get("items", {})).get(fn)
        if not item:
            return
        self.downloading = fn
        self._rebuild()

        def w():
            err = None
            try:
                download_font(fn, item)
            except TgError as e:
                err = str(e)
            except Exception:
                err = "فشل التحميل، تحقق من الانترنت"
            Clock.schedule_once(lambda dt: self._after_download(fn, err), 0)

        threading.Thread(target=w, daemon=True).start()

    def _after_download(self, fn, err):
        self.downloading = None
        if not err:
            register_user_fonts()          # التسجيل في الخيط الرئيسي
        self.status_text = err or f"تم تحميل {font_label(fn)}"
        self._rebuild()

    def pick(self, fn):
        self.app.set_font(fn)
        self._rebuild()
