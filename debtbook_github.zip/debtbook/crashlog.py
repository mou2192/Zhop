# -*- coding: utf-8 -*-
"""
سجل الأعطال. لا يستورد Kivy عمداً.
أي خطأ غير متوقع يُكتب في crash.log، ويعرضه التطبيق في نافذة عند التشغيل
التالي (أو فوراً) ليسهل تشخيصه.
"""
import sys
import threading
import traceback
from datetime import datetime

from paths import CRASH_LOG


def write_crash(text):
    try:
        with open(CRASH_LOG, "a", encoding="utf-8") as f:
            f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n" + text + "\n\n")
    except Exception:
        pass


def _excepthook(tp, val, tb):
    write_crash("".join(traceback.format_exception(tp, val, tb)))
    sys.__excepthook__(tp, val, tb)


def install():
    """يركّب معالجي الأعطال (الخيط الرئيسي + الخيوط الفرعية)."""
    sys.excepthook = _excepthook
    try:
        threading.excepthook = lambda a: write_crash(
            "".join(traceback.format_exception(a.exc_type, a.exc_value,
                                               a.exc_traceback)))
    except Exception:
        pass
