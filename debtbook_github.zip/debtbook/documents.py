# -*- coding: utf-8 -*-
"""الفواتير والسندات وكشف الحساب: نص، صورة PNG، PDF، مشاركة واتساب."""

import os
from datetime import datetime
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label as KLabel
from kivy.uix.scrollview import ScrollView
from kivy.utils import platform
from arabic import ar
from components import item_total
from fonts import current_font_path
from paths import DOC_DIR
from theme import BLUE, GRAY_BTN, GREEN, ORANGE, RED, register_theme
from utils import SELLER, money, money_signed, seller_lines
from widgets import make_arabic_popup, mk_btn, mk_text

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


MONTHS_AR = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
             "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


DAYS_AR = ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة",
           "السبت", "الأحد"]


def parse_dt(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d %H:%M")
    except Exception:
        return datetime.now()


def build_invoice_text(c, inv):
    d = parse_dt(inv.get("date", ""))
    prev, after = inv_snapshot(c, inv)
    sep = "~" * 15
    lines = [
        f"أخي {first_name(c.get('name', ''))}",
        f"تم شراء فاتورة بـ {money(inv.get('total', 0))}",
        f"{d.day} {MONTHS_AR[d.month - 1]}",
        sep,
    ]
    for i, it in enumerate(inv.get("items", []), 1):
        total = item_total(it)
        line = f"{i} {it.get('name', '')} - {money(total)} - {it.get('qty', 1):g} حبة"
        if it.get("discount"):
            line += f" - بعد خصم {money(it['discount'])}"
        if it.get("note"):
            line += f" - {it['note']}"
        lines.append(line)
    lines.append(sep)
    lines.append(f"اصبح حسابكم {money_signed(after)}")
    lines.append("يرجى السداد في اقرب وقت")
    lines.append(str(d.year))
    lines.extend(seller_lines())
    return "\n".join(lines)


def build_receipt_text(c, inv):
    d = parse_dt(inv.get("date", ""))
    prev, after = inv_snapshot(c, inv)
    return "\n".join([
        f"فاتورة سند قبض بمبلغ {money(inv.get('total', 0))}",
        f"في تاريخ {DAYS_AR[d.weekday()]} {d.day} {MONTHS_AR[d.month - 1]} {d.year}",
        f"الحساب السابق: {money_signed(prev)}",
        f"الحساب المتبقي: {money_signed(after)}",
        "شكرا على تعاملك",
    ] + seller_lines())


def build_statement_text(c):
    return "\n".join([
        f"أخي {first_name(c.get('name', ''))} هذا كشف حسابك",
        f"المطلوب منك {money_signed(c.get('balance', 0))}",
        "يرجى السداد في اقرب وقت",
        str(datetime.now().year),
    ] + seller_lines())


def open_whatsapp(phone, message):
    phone_clean = "".join(ch for ch in str(phone) if ch.isdigit())
    if phone_clean.startswith("0"):
        phone_clean = "967" + phone_clean[1:]
    from urllib.parse import quote
    url = "https://wa.me/{}?text={}".format(phone_clean, quote(message))
    if platform == "android":
        try:
            from jnius import autoclass
            from android import mActivity
            Intent = autoclass("android.content.Intent")
            Uri = autoclass("android.net.Uri")
            intent = Intent(Intent.ACTION_VIEW)
            intent.setData(Uri.parse(url))
            mActivity.startActivity(intent)
            return
        except Exception as e:
            print(f"[WA] {e}")
    print("URL:", url)


def first_name(name):
    parts = (name or "").split()
    return parts[0] if parts else "عميل"


def inv_snapshot(c, inv):
    """يرجع (الحساب السابق، الحساب بعد العملية) محسوباً من تسلسل الفواتير،
    ومربوطاً برصيد العميل الحالي، فيبقى صحيحاً بعد التعديل والحذف والمزامنة."""
    invs = c.get("invoices", [])
    running = c.get("balance", 0)
    for it in reversed(invs):
        t = it.get("total", 0)
        delta = t if it.get("kind", "فاتورة") == "فاتورة" else -t
        after = running
        prev = after - delta
        same = (it is inv) or (it.get("id") and it.get("id") == inv.get("id"))
        if same:
            return prev, after
        running = prev
    return c.get("balance", 0), c.get("balance", 0)


def _pil_font(size):
    from PIL import ImageFont
    fp = current_font_path()
    try:
        if fp:
            try:
                return ImageFont.truetype(fp, size,
                                          layout_engine=ImageFont.Layout.BASIC)
            except Exception:
                return ImageFont.truetype(fp, size)
    except Exception as e:
        print(f"[PIL FONT] {e}")
    return ImageFont.load_default()


def _save_image_as_pdf(img, pdf_path):
    """يضع صورة الفاتورة داخل صفحات A4 (الـ PDF = نفس الصورة بالضبط)."""
    from PIL import Image as PImage
    PW, PH = 1240, 1754            # A4 بدقة 150
    M = 70
    iw = PW - 2 * M
    scale = iw / float(img.width)
    pic = img.resize((iw, max(1, int(img.height * scale))), PImage.LANCZOS)
    usable = PH - 2 * M
    pages = []
    top = 0
    while top < pic.height or not pages:
        part = pic.crop((0, top, iw, min(pic.height, top + usable)))
        page = PImage.new("RGB", (PW, PH), (255, 255, 255))
        page.paste(part, (M, M))
        pages.append(page)
        top += usable
    pages[0].save(pdf_path, "PDF", resolution=150.0,
                  save_all=True, append_images=pages[1:])


def render_document(c, inv, mode, number=0):
    """ينشئ صورة PNG و PDF مرتبة. يرجع (png, pdf, (w,h)).
    mode: invoice | receipt | statement"""
    from PIL import Image as PImage, ImageDraw
    os.makedirs(DOC_DIR, exist_ok=True)
    for fn in os.listdir(DOC_DIR):
        try:
            os.remove(os.path.join(DOC_DIR, fn))
        except Exception:
            pass

    W = 900
    L, R = 50, W - 50
    rows_n = len(inv.get("items", [])) if inv else min(len(c.get("invoices", [])), 20)
    H = 1350 + rows_n * 110
    img = PImage.new("RGB", (W, H), (255, 255, 255))
    d = ImageDraw.Draw(img)

    f_title, f_big = _pil_font(60), _pil_font(52)
    f_mid, f_sm, f_xs = _pil_font(36), _pil_font(30), _pil_font(25)
    DARK, GRAY = (31, 41, 61), (118, 130, 150)
    LINE, SOFT = (228, 231, 236), (240, 243, 248)
    colors = {"invoice": (219, 84, 77), "receipt": (33, 153, 92),
              "statement": (23, 74, 125)}
    titles = {"invoice": "فاتورة", "receipt": "سند قبض", "statement": "كشف حساب"}
    color = colors[mode]

    def tw(s, font):
        try:
            return d.textlength(ar(s), font=font)
        except Exception:
            return len(s) * 14

    def rt(right, y, s, font, fill=DARK):
        d.text((right - tw(s, font), y), ar(s), font=font, fill=fill)

    def lt(left, y, s, font, fill=DARK):
        d.text((left, y), ar(s), font=font, fill=fill)

    def ct(cx, y, s, font, fill=DARK):
        d.text((cx - tw(s, font) / 2.0, y), ar(s), font=font, fill=fill)

    def fit(s, font, maxw):
        s = str(s)
        if tw(s, font) <= maxw:
            return s
        while s and tw(s + "…", font) > maxw:
            s = s[:-1]
        return s + "…"

    def kv(y, label, value, vcolor=DARK, font=None):
        font = font or f_sm
        rt(R - 20, y, label, font, GRAY)
        lt(L + 20, y, value, font, vcolor)

    # ---- الترويسة ----
    d.rectangle([0, 0, W, 170], fill=color)
    ct(W / 2, 22, titles[mode], f_title, (255, 255, 255))
    ct(W / 2, 108, "دفتر ديون الزهوب", f_xs, (235, 240, 250))

    dt = parse_dt(inv.get("date", "")) if inv else datetime.now()
    date_s = f"{DAYS_AR[dt.weekday()]} {dt.day} {MONTHS_AR[dt.month - 1]} {dt.year}"
    y = 205
    rt(R, y, f"العميل: {c.get('name', '')}", f_mid)
    if number:
        lt(L, y + 6, f"رقم: {number}", f_sm, GRAY)
    y += 56
    rt(R, y, f"التاريخ: {date_s}", f_sm, GRAY)
    if c.get("phone"):
        lt(L, y, str(c.get("phone")), f_sm, GRAY)
    y += 58
    d.line([L, y, R, y], fill=LINE, width=3)
    y += 22

    prev = after = None
    if inv:
        prev, after = inv_snapshot(c, inv)

    if mode == "invoice":
        d.rectangle([L, y, R, y + 58], fill=SOFT)
        rt(R - 14, y + 12, "م", f_sm, GRAY)
        rt(R - 90, y + 12, "الصنف", f_sm, GRAY)
        ct(L + 260, y + 12, "العدد", f_sm, GRAY)
        ct(L + 95, y + 12, "المبلغ", f_sm, GRAY)
        y += 58
        name_max = (R - 90) - (L + 350)
        for i, it in enumerate(inv.get("items", []), 1):
            total = item_total(it)
            rt(R - 14, y + 14, str(i), f_sm, GRAY)
            rt(R - 90, y + 10, fit(it.get("name", ""), f_mid, name_max), f_mid)
            ct(L + 260, y + 14, f"{it.get('qty', 1):g}", f_sm)
            ct(L + 95, y + 14, money(total), f_sm, color)
            rh = 66
            extras = []
            if it.get("discount"):
                extras.append(f"خصم {money(it['discount'])}")
            if it.get("note"):
                extras.append(str(it["note"]))
            if extras:
                rt(R - 90, y + 54, fit(" - ".join(extras), f_xs, name_max), f_xs, GRAY)
                rh = 92
            y += rh
            d.line([L, y, R, y], fill=LINE, width=2)
        y += 26
        d.rounded_rectangle([L, y, R, y + 250], radius=18, fill=SOFT)
        kv(y + 22, "إجمالي الفاتورة", money(inv.get("total", 0)), DARK, f_mid)
        kv(y + 92, "الحساب السابق", money_signed(prev), GRAY)
        d.line([L + 20, y + 150, R - 20, y + 150], fill=LINE, width=2)
        kv(y + 168, "الحساب الحالي", money_signed(after), color, f_mid)
        y += 290
        ct(W / 2, y, "يرجى السداد في أقرب وقت", f_sm, GRAY)
        y += 50

    elif mode == "receipt":
        d.rounded_rectangle([L, y, R, y + 210], radius=18, fill=SOFT)
        ct(W / 2, y + 22, "المبلغ المقبوض", f_sm, GRAY)
        ct(W / 2, y + 85, money(inv.get("total", 0)), f_title, color)
        y += 240
        note = (inv.get("items") or [{}])[0].get("name", "")
        if note:
            kv(y, "ملاحظة", fit(note, f_sm, 480))
            y += 66
        d.line([L, y, R, y], fill=LINE, width=2)
        y += 24
        kv(y, "الحساب السابق", money_signed(prev))
        y += 66
        kv(y, "الحساب المتبقي", money_signed(after), color, f_mid)
        y += 90
        ct(W / 2, y, "شكراً على تعاملك", f_sm, GRAY)
        y += 50

    else:  # statement
        d.rectangle([L, y, R, y + 58], fill=SOFT)
        rt(R - 14, y + 12, "التاريخ", f_sm, GRAY)
        ct(W / 2 + 40, y + 12, "البيان", f_sm, GRAY)
        lt(L + 14, y + 12, "المبلغ", f_sm, GRAY)
        y += 58
        invs = c.get("invoices", [])
        for it in invs[-20:]:
            k = it.get("kind", "فاتورة")
            amt = it.get("total", 0)
            dd = parse_dt(it.get("date", ""))
            rt(R - 14, y + 14, f"{dd.day} {MONTHS_AR[dd.month - 1]} {dd.year}", f_sm, DARK)
            ct(W / 2 + 40, y + 14, k, f_sm, DARK)
            if k == "فاتورة":
                lt(L + 14, y + 14, "+" + money(amt), f_sm, (219, 84, 77))
            else:
                lt(L + 14, y + 14, "-" + money(amt), f_sm, (33, 153, 92))
            y += 66
            d.line([L, y, R, y], fill=LINE, width=2)
        if len(invs) > 20:
            ct(W / 2, y + 10, f"و {len(invs) - 20} عملية سابقة", f_xs, GRAY)
            y += 50
        y += 24
        d.rounded_rectangle([L, y, R, y + 130], radius=18, fill=SOFT)
        kv(y + 36, "المطلوب منك", money_signed(c.get("balance", 0)), color, f_big)
        y += 160
        ct(W / 2, y, "يرجى السداد في أقرب وقت", f_sm, GRAY)
        y += 50

    _shop, _sphone = SELLER.get("shop", ""), SELLER.get("phone", "")
    if _shop or _sphone:
        y += 14
        d.line([L, y, R, y], fill=LINE, width=2)
        y += 22
        if _shop:
            ct(W / 2, y, fit(_shop, f_mid, W - 100), f_mid, DARK)
            y += 58
        if _sphone:
            ct(W / 2, y, "للتواصل: " + _sphone, f_sm, GRAY)
            y += 48
        y += 6
    ct(W / 2, y + 10, str(dt.year), f_xs, GRAY)
    y += 70
    img = img.crop((0, 0, W, min(y, H)))

    stamp = datetime.now().strftime("%H%M%S")
    png = os.path.join(DOC_DIR, f"doc_{mode}_{stamp}.png")
    pdf = os.path.join(DOC_DIR, f"doc_{mode}_{stamp}.pdf")
    img.save(png)
    try:
        _save_image_as_pdf(img, pdf)
    except Exception as e:
        print(f"[PDF] {e}")
        pdf = None
    return png, pdf, img.size


def _publish_media(path, mime):
    """ينسخ الملف إلى مخزن الجهاز العام ويرجع Uri يقبله واتساب."""
    from jnius import autoclass
    from android import mActivity
    sdk = autoclass("android.os.Build$VERSION").SDK_INT
    JFile = autoclass("java.io.File")
    if sdk >= 29:
        ContentValues = autoclass("android.content.ContentValues")
        resolver = mActivity.getContentResolver()
        v = ContentValues()
        v.put("_display_name", os.path.basename(path))
        v.put("mime_type", mime)
        if mime.startswith("image"):
            v.put("relative_path", "Pictures/DebtBook")
            coll = autoclass("android.provider.MediaStore$Images$Media").EXTERNAL_CONTENT_URI
        else:
            v.put("relative_path", "Download/DebtBook")
            coll = autoclass("android.provider.MediaStore$Downloads").EXTERNAL_CONTENT_URI
        uri = resolver.insert(coll, v)
        if uri is None:
            raise RuntimeError("MediaStore insert returned null")
        out = resolver.openOutputStream(uri)
        try:
            autoclass("java.nio.file.Files").copy(JFile(path).toPath(), out)
        finally:
            out.close()
        return uri

    # [إصلاح كراش 5] أندرويد 9 وأقدم (SDK < 29): حُذف الكتابة في
    # getExternalStorageDirectory()/Download. نستخدم مجلد التطبيق الخارجي الخاص
    # getExternalFilesDir(null) (لا يحتاج أي صلاحية)، ونمرّر Uri.fromFile لواتساب.
    ext = mActivity.getExternalFilesDir(None)
    base = ext.getAbsolutePath() if ext is not None else os.path.dirname(path)
    pub_dir = os.path.join(base, "DebtBook")
    os.makedirs(pub_dir, exist_ok=True)
    pub_path = os.path.join(pub_dir, os.path.basename(path))
    import shutil
    shutil.copyfile(path, pub_path)
    StrictMode = autoclass("android.os.StrictMode")
    Builder = autoclass("android.os.StrictMode$VmPolicy$Builder")
    StrictMode.setVmPolicy(Builder().build())
    return autoclass("android.net.Uri").fromFile(JFile(pub_path))


def share_file(path, mime, phone=""):
    """يشارك ملفاً (صورة/PDF) عبر واتساب، وإن لم يتوفر يفتح قائمة المشاركة.
    يرجع None عند النجاح، أو نص الخطأ عند الفشل."""
    if platform != "android":
        print("[SHARE]", path)
        return None
    try:
        from jnius import autoclass, cast
        from android import mActivity
        Intent = autoclass("android.content.Intent")
        uri = _publish_media(path, mime)

        def make():
            it = Intent(Intent.ACTION_SEND)
            it.setType(mime)
            it.putExtra(Intent.EXTRA_STREAM, cast("android.os.Parcelable", uri))
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            return it

        p = "".join(ch for ch in str(phone) if ch.isdigit())
        if p.startswith("0"):
            p = "967" + p[1:]
        for pkg in ("com.whatsapp", "com.whatsapp.w4b"):
            try:
                it = make()
                it.setPackage(pkg)
                if p:
                    it.putExtra("jid", p + "@s.whatsapp.net")
                mActivity.startActivity(it)
                return None
            except Exception as e:
                print(f"[SHARE {pkg}] {e}")
        chooser = Intent.createChooser(make(), "إرسال")
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        mActivity.startActivity(chooser)
        return None
    except Exception as e:
        print(f"[SHARE] {e}")
        return str(e)[:160]


def make_doc_image(path, size):
    from kivy.uix.image import Image as KImage
    try:
        img = KImage(source=path, fit_mode="contain", size_hint=(1, None))
    except Exception:
        img = KImage(source=path, allow_stretch=True, keep_ratio=True,
                     size_hint=(1, None))
    ratio = size[1] / float(size[0])
    img.height = Window.width * 0.9 * ratio
    img.bind(width=lambda w, v: setattr(w, "height", v * ratio))
    return img


def _share_and_report(path, mime, phone):
    err = share_file(path, mime, phone)
    if err:
        box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(10))
        box.add_widget(mk_text("تعذر الإرسال. سبب الخطأ:", dp(15), RED,
                               halign="center", height=dp(30)))
        lbl = KLabel(text=err, color=(0.3, 0.3, 0.3, 1), font_size=dp(12),
                     halign="center", valign="middle")
        lbl.bind(size=lambda w, v: setattr(w, "text_size", (v[0], None)))
        box.add_widget(lbl)
        ok = mk_btn("حسناً", height=dp(46), background_color=GRAY_BTN)
        box.add_widget(ok)
        pop = make_arabic_popup("خطأ في الإرسال", box, size_hint=(0.88, 0.42),
                                title_color=RED, separator_color=RED)
        ok.bind(on_release=lambda *a: pop.dismiss())
        pop.open()


def show_document_popup(c, inv, mode, number=0, send=True):
    """يعرض الفاتورة/السند/الكشف كصورة مرتبة مع أزرار (صورة / PDF / نص)."""
    try:
        png, pdf, size = render_document(c, inv, mode, number)
    except Exception as e:
        print(f"[RENDER] {e}")
        png = pdf = size = None

    if mode == "receipt":
        text = build_receipt_text(c, inv)
        title = "معاينة سند القبض"
    elif mode == "invoice":
        text = build_invoice_text(c, inv)
        title = "معاينة الفاتورة"
    else:
        text = build_statement_text(c)
        title = "معاينة كشف الحساب"
    phone = c.get("phone", "")

    content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(4))
    if png:
        sv = ScrollView(size_hint=(1, 1), bar_width=dp(3))
        sv.add_widget(make_doc_image(png, size))
        content.add_widget(sv)
    else:
        content.add_widget(mk_text("تعذر إنشاء الصورة، يمكنك الإرسال كنص",
                                   dp(14), RED, halign="center"))

    b_img = b_pdf = b_txt = None
    if send:
        r1 = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(6))
        b_img = mk_btn("إرسال صورة", background_color=GREEN, font_size=dp(14))
        b_pdf = mk_btn("إرسال PDF", background_color=ORANGE, font_size=dp(14))
        r1.add_widget(b_img)
        r1.add_widget(b_pdf)
        content.add_widget(r1)
    r2 = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(6))
    if send:
        b_txt = mk_btn("إرسال كنص", background_color=BLUE, font_size=dp(14))
        r2.add_widget(b_txt)
    b_close = mk_btn("إغلاق", background_color=GRAY_BTN, font_size=dp(14))
    r2.add_widget(b_close)
    content.add_widget(r2)

    popup = make_arabic_popup(title, content, size_hint=(0.96, 0.94))
    if send:
        if png:
            b_img.bind(on_release=lambda *a: _share_and_report(png, "image/png", phone))
        if pdf:
            b_pdf.bind(on_release=lambda *a: _share_and_report(pdf, "application/pdf", phone))
        b_txt.bind(on_release=lambda *a: open_whatsapp(phone, text))
    b_close.bind(on_release=lambda *a: popup.dismiss())
    popup.open()
