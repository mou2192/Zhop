# -*- coding: utf-8 -*-
"""مكونات الواجهة: النص المرسوم، الأزرار، البطاقات، حقل الإدخال، النوافذ."""

import weakref
from kivy.clock import Clock
from kivy.core.text import Label as CoreLabel
from kivy.core.window import Window
from kivy.graphics import (Color, Ellipse, PopMatrix, PushMatrix, Rectangle,
    RoundedRectangle, Translate)
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from arabic import ar
from fonts import _font_name
from theme import (AVATAR_COLORS, BLUE, BORDER, CARD, GLASS, HINT, INPUT_BG,
    INPUT_BORDER, PRIMARY, TEXT, WHITE, is_dark, register_theme)

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


def _auto_padding():
    try:
        w = Window.width
        if w <= 0:
            return dp(14)
        p = w * 0.03
        p = max(dp(10), min(dp(20), p))
        return p
    except Exception:
        return dp(14)


_ALL_TEXTS = weakref.WeakSet()


class DrawnText(Widget):
    _tex_cache = {}

    def __init__(self, text="", font_size=dp(15), color=None,
                 halign="right", valign="middle", padding_x=None,
                 min_size=dp(9), line_gap=dp(3), font_override=None, **kwargs):
        super().__init__(**kwargs)
        self._font_override = font_override
        if color is None:
            color = TEXT
        self._raw_text = ""
        self._lines = []
        self._font_size = float(font_size)
        self._color = color
        self._halign = halign
        self._valign = valign
        if padding_x is None:
            self._padding_x = _auto_padding()
        else:
            self._padding_x = padding_x
        self._min_size = float(min_size)
        self._line_gap = line_gap
        self._rendered = None
        self._rects = []
        self._trans = None
        _ALL_TEXTS.add(self)
        self.bind(size=self._on_size, pos=self._on_pos)
        self.text = text
        Clock.schedule_once(lambda dt: self.force_refresh(), 0.1)

    @property
    def text(self):
        return self._raw_text

    @text.setter
    def text(self, value):
        self._raw_text = str(value) if value is not None else ""
        self._lines = [ar(line) for line in self._raw_text.split("\n")]
        self._rendered = None
        self._redraw()

    def _get_tex(self, display, size_int):
        fname = getattr(self, "_font_override", None) or _font_name()
        key = (display, size_int, fname, tuple(self._color))
        cached = DrawnText._tex_cache.get(key)
        if cached is not None:
            return cached
        tex = None
        attempts = [
            dict(text=display, font_size=size_int, font_name=fname,
                 color=self._color, halign="left", valign="middle",
                 padding=(0, 0, 0, 0)),
            dict(text=display, font_size=size_int, font_name=fname,
                 color=self._color),
            dict(text=display, font_size=size_int, font_name=fname),
        ]
        for opts in attempts:
            try:
                cl = CoreLabel(**opts)
                cl.refresh()
                tex = cl.texture
                if tex is not None:
                    break
            except Exception as e:
                print(f"[TEX ERR] {e}")
        if tex is not None:
            DrawnText._tex_cache[key] = tex
        return tex

    def _measure_line_height(self, size_int):
        t = self._get_tex("م", size_int)
        if t is not None and t.height > 0:
            return int(t.height)
        return int(size_int * 1.35)

    def _render_at(self, size_int):
        h = self._measure_line_height(size_int)
        out = []
        for line in self._lines:
            tex = self._get_tex(line, size_int) if line else None
            out.append((tex, h))
        return out

    def _compute_locked(self, avail):
        size = float(self._font_size)
        for _ in range(6):
            size_int = max(int(self._min_size), int(round(size)))
            rendered = self._render_at(size_int)
            widest = 0
            for tex, _h in rendered:
                if tex is not None and tex.width > widest:
                    widest = tex.width
            if widest <= avail or size_int <= int(self._min_size):
                return size_int, rendered
            ratio = avail / float(widest)
            new_size = max(self._min_size, size * ratio * 0.98)
            if new_size >= size - 0.5:
                return size_int, rendered
            size = new_size
        size_int = max(int(self._min_size), int(round(size)))
        return size_int, self._render_at(size_int)

    def _on_size(self, *args):
        if self.width < 2 or self.height < 2:
            return
        self._rendered = None
        self._redraw()

    def _on_pos(self, *args):
        t = getattr(self, "_trans", None)
        if t is not None:
            t.xy = (int(round(self.x)), int(round(self.y)))

    def force_refresh(self):
        self._rendered = None
        self._redraw()

    def _redraw(self):
        if self.width < 2 or self.height < 2:
            return
        if not any(self._lines):
            self.canvas.clear()
            self._rects = []
            self._rendered = None
            self._trans = None
            return
        try:
            W, H = self.width, self.height
            avail = max(W - 2 * self._padding_x, dp(4))
            size_int, rendered = self._compute_locked(avail)
            self._rendered = rendered
            self.canvas.clear()
            self._rects = []
            heights = [h for _t, h in rendered]
            total_h = sum(heights) + self._line_gap * (len(heights) - 1)
            if self._valign == "top":
                y_top = H
            elif self._valign == "bottom":
                y_top = total_h
            else:
                y_top = (H + total_h) / 2.0
            with self.canvas:
                PushMatrix()
                self._trans = Translate(int(round(self.x)), int(round(self.y)))
                Color(1, 1, 1, 1)
                for i, (tex, h) in enumerate(rendered):
                    y_bottom = y_top - h
                    if tex is not None:
                        tw = tex.width
                        th = tex.height
                        if tw > avail:
                            k = avail / float(tw)
                            tw, th = tw * k, th * k
                        if self._halign == "right":
                            x = W - tw - self._padding_x
                        elif self._halign == "center":
                            x = W / 2.0 - tw / 2.0
                        else:
                            x = self._padding_x
                        y_draw = y_bottom + (h - th) / 2.0
                        rect = Rectangle(texture=tex,
                                         pos=(int(x), int(y_draw)),
                                         size=(tw, th))
                        self._rects.append(rect)
                    else:
                        self._rects.append(None)
                    y_top = y_bottom - self._line_gap
                PopMatrix()
        except Exception as e:
            print(f"[DrawnText redraw] {e}")


def refresh_all_texts(*args):
    for w in list(_ALL_TEXTS):
        try:
            w.force_refresh()
        except Exception:
            pass


def schedule_refresh(delay=0.05):
    Clock.schedule_once(refresh_all_texts, delay)


class DrawnLabel(FloatLayout):
    def __init__(self, text="", font_size=dp(15), color=None,
                 halign="right", **kwargs):
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(28))
        super().__init__(**kwargs)
        self._dt = DrawnText(text=text, font_size=font_size, color=color,
                             halign=halign,
                             size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
        self._dt.disabled = True
        self.add_widget(self._dt)

    @property
    def text(self):
        return self._dt.text

    @text.setter
    def text(self, value):
        self._dt.text = value


class DrawnButton(FloatLayout):
    def __init__(self, text="", font_size=dp(15), color=WHITE,
                 background_color=(0.3, 0.5, 0.7, 1),
                 halign="center", on_release=None, **kwargs):
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(46))
        self._on_release_cbs = []
        super().__init__(**kwargs)
        self._bg_color = tuple(background_color)
        self._pressed_rect = None

        with self.canvas.before:
            self._bg_col = Color(*self._bg_color)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size,
                                        radius=[dp(12)])
        self.bind(pos=self._update_bg, size=self._update_bg)

        self._dt = DrawnText(text=text, font_size=font_size, color=color,
                             halign=halign,
                             size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
        self._dt.disabled = True
        self.add_widget(self._dt)

        if on_release:
            self._on_release_cbs.append(on_release)

    def _update_bg(self, *args):
        self._bg.pos = self.pos
        self._bg.size = self.size
        if self._pressed_rect:
            self._pressed_rect.pos = self.pos
            self._pressed_rect.size = self.size

    def bind(self, **kwargs):
        if "on_release" in kwargs:
            self._on_release_cbs.append(kwargs.pop("on_release"))
        if kwargs:
            return super().bind(**kwargs)

    def set_bg(self, rgba):
        self._bg_color = tuple(rgba)
        self._bg_col.rgba = tuple(rgba)

    def _show_pressed(self):
        if self._pressed_rect:
            return
        try:
            r, g, b = self._bg_color[:3]
            a = self._bg_color[3] if len(self._bg_color) > 3 else 1
            with self.canvas.before:
                Color(r * 0.75, g * 0.75, b * 0.75, min(1, a + 0.15))
                self._pressed_rect = RoundedRectangle(pos=self.pos,
                                                      size=self.size,
                                                      radius=[dp(12)])
        except Exception:
            pass

    def _hide_pressed(self):
        if self._pressed_rect:
            try:
                self.canvas.before.remove(self._pressed_rect)
            except Exception:
                pass
            self._pressed_rect = None

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos) and not self.disabled:
            self._show_pressed()
            return True
        return super().on_touch_down(touch)

    def on_touch_up(self, touch):
        if self.collide_point(*touch.pos) and not self.disabled:
            self._hide_pressed()
            for cb in list(self._on_release_cbs):
                try:
                    cb(self)
                except Exception as e:
                    print(f"[CB] {e}")
            return True
        self._hide_pressed()
        return super().on_touch_up(touch)

    @property
    def text(self):
        return self._dt.text

    @text.setter
    def text(self, value):
        self._dt.text = value


def mk_btn(text, **kw):
    font_size = kw.pop("font_size", dp(15))
    color = kw.pop("color", WHITE)
    bg = kw.pop("background_color", (0.3, 0.5, 0.7, 1))
    on_release = kw.pop("on_release", None)
    height = kw.pop("height", None)
    if height is not None and "size" not in kw:
        kw["height"] = height
    return DrawnButton(text=text, font_size=font_size, color=color,
                       background_color=bg, on_release=on_release, **kw)


def mk_text(text, size=dp(15), color=None, halign="right",
            height=None, hint_y=None, width=None, hint_x=1, pad=None):
    if color is None:
        color = TEXT
    kw = {}
    if height is not None:
        kw["size_hint_y"] = None
        kw["height"] = height
    elif hint_y is not None:
        kw["size_hint_y"] = hint_y
    else:
        kw["size_hint_y"] = 1
    if width is not None:
        kw["size_hint_x"] = None
        kw["width"] = width
    else:
        kw["size_hint_x"] = hint_x
    w = DrawnText(text=text, font_size=size, color=color,
                  halign=halign, padding_x=pad, **kw)
    w.disabled = True
    return w


class CardBox(BoxLayout):
    def __init__(self, on_tap=None, bg=None, radius=dp(14),
                 shadow=True, **kwargs):
        super().__init__(**kwargs)
        if bg is None:
            bg = CARD
        self._on_tap = on_tap
        self._bg = tuple(bg)
        self._border_on = bool(is_dark() and shadow)
        self._inset = dp(1) if self._border_on else 0
        self._radius = radius
        self._down = False
        self._start = (0, 0)
        self._has_shadow = shadow

        with self.canvas.before:
            if shadow:
                Color(0, 0, 0, 0.035)
                self._sh1 = RoundedRectangle(
                    pos=(self.x - dp(2), self.y - dp(4)),
                    size=(self.width + dp(4), self.height + dp(4)),
                    radius=[radius + dp(2)])
                Color(0, 0, 0, 0.05)
                self._sh2 = RoundedRectangle(
                    pos=(self.x - dp(1), self.y - dp(2)),
                    size=(self.width + dp(2), self.height + dp(2)),
                    radius=[radius + dp(1)])
            if self._border_on:
                Color(*BORDER)
                self._bd = RoundedRectangle(pos=self.pos, size=self.size,
                                            radius=[radius])
            self._col = Color(*self._bg)
            i = self._inset
            self._rect = RoundedRectangle(
                pos=(self.x + i, self.y + i),
                size=(self.width - 2 * i, self.height - 2 * i),
                radius=[radius])
        self.bind(pos=self._upd, size=self._upd)

    def _upd(self, *a):
        if self._has_shadow:
            self._sh1.pos = (self.x - dp(2), self.y - dp(4))
            self._sh1.size = (self.width + dp(4), self.height + dp(4))
            self._sh2.pos = (self.x - dp(1), self.y - dp(2))
            self._sh2.size = (self.width + dp(2), self.height + dp(2))
        i = self._inset
        if self._border_on:
            self._bd.pos = self.pos
            self._bd.size = self.size
        self._rect.pos = (self.x + i, self.y + i)
        self._rect.size = (self.width - 2 * i, self.height - 2 * i)

    def _pressed_color(self):
        r, g, b, a = self._bg
        if is_dark():
            return (min(1, r + 0.05), min(1, g + 0.05), min(1, b + 0.07), a)
        return (r * 0.94, g * 0.94, b * 0.95, a)

    def on_touch_down(self, touch):
        if self._on_tap is None:
            return super().on_touch_down(touch)
        if self.collide_point(*touch.pos):
            self._down = True
            self._start = touch.pos
            self._col.rgba = self._pressed_color()
            return True
        return False

    def on_touch_move(self, touch):
        if self._on_tap is None:
            return super().on_touch_move(touch)
        if self._down:
            if (abs(touch.y - self._start[1]) > dp(12)
                    or abs(touch.x - self._start[0]) > dp(12)):
                self._down = False
                self._col.rgba = self._bg
        return False

    def on_touch_up(self, touch):
        if self._on_tap is None:
            return super().on_touch_up(touch)
        if self._down:
            self._down = False
            self._col.rgba = self._bg
            if self.collide_point(*touch.pos):
                cb = self._on_tap
                Clock.schedule_once(lambda dt: cb(), 0)
            return True
        self._col.rgba = self._bg
        return False


class Avatar(FloatLayout):
    def __init__(self, name="", diameter=dp(48), **kwargs):
        kwargs["size_hint"] = (None, None)
        kwargs["size"] = (diameter, diameter)
        super().__init__(**kwargs)
        name = (name or "").strip()
        letter = name[0] if name else "?"
        idx = sum(ord(c) for c in name) % len(AVATAR_COLORS)
        with self.canvas.before:
            Color(*AVATAR_COLORS[idx])
            self._circle = Ellipse(pos=self.pos, size=self.size)
        self.bind(pos=self._upd, size=self._upd)
        t = DrawnText(text=letter.upper(), font_size=dp(21), color=WHITE,
                      halign="center", padding_x=0,
                      size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
        t.disabled = True
        self.add_widget(t)

    def _upd(self, *a):
        self._circle.pos = self.pos
        self._circle.size = self.size


class ArabicTextInput(FloatLayout):
    def __init__(self, hint_text="", multiline=False, input_filter=None,
                 font_size=dp(15), **kwargs):
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(46))
        super().__init__(**kwargs)
        self._font_size = font_size
        self._padding_x = _auto_padding()
        self._cursor_visible = False
        self._blink_event = None

        with self.canvas.before:
            self._border_col = Color(*INPUT_BORDER)
            self._border = RoundedRectangle(pos=self.pos, size=self.size,
                                            radius=[dp(10)])
            Color(*INPUT_BG)
            self._bg = RoundedRectangle(
                pos=(self.x + dp(1), self.y + dp(1)),
                size=(self.width - dp(2), self.height - dp(2)),
                radius=[dp(9)])

        self._input = TextInput(
            multiline=multiline, input_filter=input_filter,
            font_size=font_size,
            background_color=(0, 0, 0, 0), background_normal="",
            background_active="",
            foreground_color=(0, 0, 0, 0), cursor_color=(0, 0, 0, 0),
            cursor_width=0, use_bubble=False, use_handles=False,
            hint_text="", padding=[dp(8), dp(10), dp(8), dp(10)],
            size_hint=(1, 1), pos_hint={"x": 0, "y": 0})

        self._display = DrawnText(text="", font_size=font_size, color=TEXT,
                                  halign="right", padding_x=self._padding_x,
                                  size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
        self._display.disabled = True

        self._hint = DrawnText(text=hint_text, font_size=font_size, color=HINT,
                               halign="right", padding_x=self._padding_x,
                               size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
        self._hint.disabled = True

        with self.canvas:
            self._cursor_color = Color(0, 0, 0, 0)
            self._cursor_rect = Rectangle(pos=(0, 0), size=(0, 0))

        self.add_widget(self._hint)
        self.add_widget(self._display)
        self.add_widget(self._input)
        self._input.bind(text=self._on_text_change)
        self._input.bind(focus=self._on_focus)
        try:
            self._input.bind(cursor=self._on_cursor_move)
        except Exception:
            pass
        self.bind(pos=self._on_resize, size=self._on_resize)
        self._update_display()

    def _on_resize(self, *args):
        self._border.pos = self.pos
        self._border.size = self.size
        self._bg.pos = (self.x + dp(1), self.y + dp(1))
        self._bg.size = (self.width - dp(2), self.height - dp(2))
        Clock.schedule_once(lambda dt: self._redraw_cursor(), 0)

    def _on_text_change(self, instance, value):
        self._update_display()

    def _on_focus(self, instance, value):
        self._update_display()
        if value:
            self._border_col.rgba = BLUE
            self._start_cursor_blink()
        else:
            self._border_col.rgba = INPUT_BORDER
            self._stop_cursor_blink()

    def _on_cursor_move(self, instance, value):
        Clock.schedule_once(lambda dt: self._redraw_cursor(), 0)

    def _start_cursor_blink(self):
        self._stop_cursor_blink()
        self._cursor_visible = True
        self._blink_event = Clock.schedule_interval(self._blink_cursor, 0.5)
        Clock.schedule_once(lambda dt: self._redraw_cursor(), 0)

    def _stop_cursor_blink(self):
        if self._blink_event:
            self._blink_event.cancel()
            self._blink_event = None
        self._cursor_visible = False
        self._cursor_color.a = 0

    def _blink_cursor(self, dt):
        self._cursor_visible = not self._cursor_visible
        self._redraw_cursor()

    def _measure_text_width(self, text):
        if not text:
            return 0
        try:
            cl = CoreLabel(text=text, font_size=int(self._font_size),
                           font_name=_font_name(), padding=(0, 0, 0, 0))
            cl.refresh()
            if cl.texture:
                return cl.texture.size[0]
        except Exception:
            pass
        return 0

    def _redraw_cursor(self):
        if not self._input.focus or not self._cursor_visible:
            self._cursor_color.a = 0
            return
        try:
            raw = self._input.text
            if not raw:
                cursor_x = self.right - self._padding_x
            else:
                display = ar(raw.split("\n")[-1])
                text_width = self._measure_text_width(display)
                cursor_x = self.right - self._padding_x - text_width - dp(2)
            min_x = self.x + dp(2)
            max_x = self.right - dp(2)
            if cursor_x < min_x:
                cursor_x = min_x
            if cursor_x > max_x:
                cursor_x = max_x
            cursor_y = self.y + dp(9)
            cursor_h = self.height - dp(18)
            self._cursor_color.rgba = BLUE
            self._cursor_rect.pos = (cursor_x, cursor_y)
            self._cursor_rect.size = (dp(2), cursor_h)
        except Exception as e:
            print(f"[Cursor] {e}")

    def _update_display(self):
        raw = self._input.text
        if raw:
            self._display.text = raw
            self._hint.opacity = 0
        else:
            self._display.text = ""
            self._hint.opacity = 1
        Clock.schedule_once(lambda dt: self._redraw_cursor(), 0)

    @property
    def text(self):
        return self._input.text

    @text.setter
    def text(self, value):
        self._input.text = value

    def bind(self, **kwargs):
        if "text" in kwargs:
            self._input.bind(text=kwargs["text"])
            kwargs = {k: v for k, v in kwargs.items() if k != "text"}
        if kwargs:
            return super().bind(**kwargs)


def mk_input(**kw):
    hint = kw.pop("hint_text", "")
    multiline = kw.pop("multiline", False)
    input_filter = kw.pop("input_filter", None)
    font_size = kw.pop("font_size", dp(15))
    return ArabicTextInput(hint_text=hint, multiline=multiline,
                           input_filter=input_filter,
                           font_size=font_size, **kw)


def make_arabic_popup(title_text, content, size_hint=(0.9, 0.7),
                      title_color=None, separator_color=None,
                      auto_dismiss=True):
    if title_color is None:
        title_color = PRIMARY
    if separator_color is None:
        separator_color = PRIMARY
    wrapper = BoxLayout(orientation="vertical", spacing=0)
    title_widget = DrawnText(text=title_text, font_size=dp(18),
                             color=title_color, halign="center",
                             size_hint_y=None, height=dp(44))
    title_widget.disabled = True
    wrapper.add_widget(title_widget)

    sep = Widget(size_hint_y=None, height=dp(2))
    with sep.canvas:
        Color(*separator_color)
        sep_rect = Rectangle(pos=sep.pos, size=sep.size)

    def _update_sep(*a):
        sep_rect.pos = sep.pos
        sep_rect.size = sep.size
    sep.bind(pos=_update_sep, size=_update_sep)
    wrapper.add_widget(sep)
    wrapper.add_widget(Widget(size_hint_y=None, height=dp(8)))
    content.size_hint_y = 1
    wrapper.add_widget(content)

    popup = Popup(title="", content=wrapper, size_hint=size_hint,
                  separator_color=(0, 0, 0, 0),
                  background="", background_color=CARD,
                  auto_dismiss=auto_dismiss)
    popup.bind(on_open=lambda *a: schedule_refresh(0.05))
    return popup


class _FadeOverlay(Widget):
    def __init__(self, color, **kwargs):
        kwargs.setdefault("size_hint", (None, None))
        kwargs.setdefault("size", Window.size)
        kwargs.setdefault("pos", (0, 0))
        super().__init__(**kwargs)
        with self.canvas:
            Color(*color)
            Rectangle(pos=(0, 0), size=Window.size)

    def on_touch_down(self, touch):
        return False

    def on_touch_up(self, touch):
        return False


def make_header(title, color, on_back=None, right_widget=None,
                height=dp(58), on_back_text="رجوع"):
    bar = FloatLayout(size_hint_y=None, height=height)
    with bar.canvas.before:
        Color(*color)
        rect = RoundedRectangle(pos=bar.pos, size=bar.size,
                                radius=[0, 0, dp(20), dp(20)])

    def _u(*a):
        rect.pos = bar.pos
        rect.size = bar.size
    bar.bind(pos=_u, size=_u)

    t = DrawnText(text=title, font_size=dp(19), color=WHITE, halign="center",
                  size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
    t.disabled = True
    bar.add_widget(t)

    if on_back is not None:
        back = mk_btn(on_back_text, size_hint=(None, None),
                      size=(dp(76), dp(38)), font_size=dp(14),
                      background_color=GLASS,
                      pos_hint={"x": 0.02, "center_y": 0.5})
        back.bind(on_release=on_back)
        bar.add_widget(back)

    if right_widget is not None:
        right_widget.pos_hint = {"right": 0.98, "center_y": 0.5}
        bar.add_widget(right_widget)
    return bar


def make_body(**kw):
    kw.setdefault("orientation", "vertical")
    kw.setdefault("padding", [dp(12), dp(2), dp(12), dp(10)])
    kw.setdefault("spacing", dp(8))
    return BoxLayout(**kw)


def make_scroll_list(spacing=dp(10)):
    layout = GridLayout(cols=1, spacing=spacing, size_hint_y=None,
                        padding=[dp(2), dp(4), dp(2), dp(16)])
    layout.bind(minimum_height=layout.setter("height"))
    scroll = ScrollView(size_hint=(1, 1), bar_width=dp(3))
    scroll.add_widget(layout)
    return scroll, layout
