# -*- coding: utf-8 -*-
"""تشكيل الحروف العربية للعرض الصحيح."""




ARABIC_FORMS = {
    '\u0627': ('\uFE8D', '\uFE8D', '\uFE8E', '\uFE8E', False),
    '\u0622': ('\uFE81', '\uFE81', '\uFE82', '\uFE82', False),
    '\u0623': ('\uFE83', '\uFE83', '\uFE84', '\uFE84', False),
    '\u0625': ('\uFE87', '\uFE87', '\uFE88', '\uFE88', False),
    '\u0624': ('\uFE85', '\uFE85', '\uFE86', '\uFE86', False),
    '\u0629': ('\uFE93', '\uFE93', '\uFE94', '\uFE94', False),
    '\u062F': ('\uFEA9', '\uFEA9', '\uFEAA', '\uFEAA', False),
    '\u0630': ('\uFEAB', '\uFEAB', '\uFEAC', '\uFEAC', False),
    '\u0631': ('\uFEAD', '\uFEAD', '\uFEAE', '\uFEAE', False),
    '\u0632': ('\uFEAF', '\uFEAF', '\uFEB0', '\uFEB0', False),
    '\u0648': ('\uFEED', '\uFEED', '\uFEEE', '\uFEEE', False),
    '\u0649': ('\uFEEF', '\uFEEF', '\uFEF0', '\uFEF0', False),
    '\u0621': ('\uFE80', '\uFE80', '\uFE80', '\uFE80', False),
    '\u0626': ('\uFE89', '\uFE8B', '\uFE8C', '\uFE8A', True),
    '\u0628': ('\uFE8F', '\uFE91', '\uFE92', '\uFE90', True),
    '\u062A': ('\uFE95', '\uFE97', '\uFE98', '\uFE96', True),
    '\u062B': ('\uFE99', '\uFE9B', '\uFE9C', '\uFE9A', True),
    '\u062C': ('\uFE9D', '\uFE9F', '\uFEA0', '\uFE9E', True),
    '\u062D': ('\uFEA1', '\uFEA3', '\uFEA4', '\uFEA2', True),
    '\u062E': ('\uFEA5', '\uFEA7', '\uFEA8', '\uFEA6', True),
    '\u0633': ('\uFEB1', '\uFEB3', '\uFEB4', '\uFEB2', True),
    '\u0634': ('\uFEB5', '\uFEB7', '\uFEB8', '\uFEB6', True),
    '\u0635': ('\uFEB9', '\uFEBB', '\uFEBC', '\uFEBA', True),
    '\u0636': ('\uFEBD', '\uFEBF', '\uFEC0', '\uFEBE', True),
    '\u0637': ('\uFEC1', '\uFEC3', '\uFEC4', '\uFEC2', True),
    '\u0638': ('\uFEC5', '\uFEC7', '\uFEC8', '\uFEC6', True),
    '\u0639': ('\uFEC9', '\uFECB', '\uFECC', '\uFECA', True),
    '\u063A': ('\uFECD', '\uFECF', '\uFED0', '\uFECE', True),
    '\u0641': ('\uFED1', '\uFED3', '\uFED4', '\uFED2', True),
    '\u0642': ('\uFED5', '\uFED7', '\uFED8', '\uFED6', True),
    '\u0643': ('\uFED9', '\uFEDB', '\uFEDC', '\uFEDA', True),
    '\u0644': ('\uFEDD', '\uFEDF', '\uFEE0', '\uFEDE', True),
    '\u0645': ('\uFEE1', '\uFEE3', '\uFEE4', '\uFEE2', True),
    '\u0646': ('\uFEE5', '\uFEE7', '\uFEE8', '\uFEE6', True),
    '\u0647': ('\uFEE9', '\uFEEB', '\uFEEC', '\uFEEA', True),
    '\u064A': ('\uFEF1', '\uFEF3', '\uFEF4', '\uFEF2', True),
}


DIACRITICS = set('\u064B\u064C\u064D\u064E\u064F\u0650\u0651\u0652\u0653\u0654\u0655\u0670\u0640')


LAM_ALEF = {
    '\u0644\u0622': ('\uFEF5', '\uFEF6'),
    '\u0644\u0623': ('\uFEF7', '\uFEF8'),
    '\u0644\u0625': ('\uFEF9', '\uFEFA'),
    '\u0644\u0627': ('\uFEFB', '\uFEFC'),
}


def is_arabic_char(ch):
    return ('\u0600' <= ch <= '\u06FF') or ('\uFB50' <= ch <= '\uFEFF')


def _prev_element_connects(chars, idx):
    for j in range(idx - 1, -1, -1):
        kind, ch = chars[j]
        if kind == 'C':
            if ch in DIACRITICS:
                continue
            if ch in ARABIC_FORMS:
                return ARABIC_FORMS[ch][4]
            return False
        if kind == 'PAIR':
            return False
    return False


def _has_element_after(chars, idx):
    for j in range(idx + 1, len(chars)):
        kind, ch = chars[j]
        if kind == 'C':
            if ch in DIACRITICS:
                continue
            if ch in ARABIC_FORMS:
                return True
            return False
        if kind == 'PAIR':
            return True
    return False


def shape_word(word):
    if not word:
        return ""
    chars = []
    i = 0
    while i < len(word):
        if i + 1 < len(word):
            pair = word[i:i + 2]
            if pair in LAM_ALEF:
                chars.append(('PAIR', pair))
                i += 2
                continue
        chars.append(('C', word[i]))
        i += 1
    result = []
    for idx in range(len(chars)):
        kind, value = chars[idx]
        if kind == 'PAIR':
            prev_conn = _prev_element_connects(chars, idx)
            iso, fin = LAM_ALEF[value]
            result.append(fin if prev_conn else iso)
            continue
        ch = value
        if ch in DIACRITICS:
            result.append(ch)
            continue
        if ch in ARABIC_FORMS:
            isolated, initial, medial, final, connects_fwd = ARABIC_FORMS[ch]
            prev_conn = _prev_element_connects(chars, idx)
            next_exists = _has_element_after(chars, idx)
            if prev_conn and connects_fwd and next_exists:
                result.append(medial)
            elif prev_conn:
                result.append(final)
            elif connects_fwd and next_exists:
                result.append(initial)
            else:
                result.append(isolated)
        else:
            result.append(ch)
    result.reverse()
    return ''.join(result)


def ar(text):
    if not text:
        return ""
    text = str(text)
    segments = []
    current = []
    current_is_ar = None
    for ch in text:
        if ch.isspace():
            if current:
                segments.append((current_is_ar, ''.join(current)))
                current = []
                current_is_ar = None
            segments.append((None, ch))
        else:
            ch_is_ar = is_arabic_char(ch)
            if current_is_ar is None:
                current_is_ar = ch_is_ar
                current.append(ch)
            elif ch_is_ar == current_is_ar:
                current.append(ch)
            else:
                segments.append((current_is_ar, ''.join(current)))
                current = [ch]
                current_is_ar = ch_is_ar
    if current:
        segments.append((current_is_ar, ''.join(current)))
    out = []
    for is_ar, seg in segments:
        if is_ar is True:
            out.append(shape_word(seg))
        else:
            out.append(seg)
    has_ar = any(x is True for x, _ in segments)
    if has_ar:
        out.reverse()
    return ''.join(out)
