# -*- coding: utf-8 -*-
"""قراءة وحفظ بيانات التطبيق (JSON) على الجهاز."""

import json
import os
from paths import DATA_FILE
from utils import gen_id


def load_json(path, default):
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return default


def save_json(path, data):
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except Exception as e:
        print(f"[SAVE] {e}")


def load_data():
    d = load_json(DATA_FILE, None)
    if d is None:
        return {"clients": [], "user": None, "_tg_meta": {},
                "_deleted": [], "owner": None}
    if "clients" not in d:
        d["clients"] = []
    if "user" not in d:
        d["user"] = None
    if "_tg_meta" not in d:
        d["_tg_meta"] = {}
    if "_deleted" not in d:
        d["_deleted"] = []
    if not d.get("owner") and (d.get("user") or {}).get("email"):
        d["owner"] = d["user"]["email"]
    for c in d.get("clients", []):
        if "invoices" not in c:
            c["invoices"] = []
        if "id" not in c:
            c["id"] = gen_id()
        for inv in c["invoices"]:
            if "id" not in inv:
                inv["id"] = gen_id()
    return d


def save_data(data):
    save_json(DATA_FILE, data)
