[app]

# ---- App info ----
# Title shown on the phone. Change it if you like (keep it English to be safe).
title = Debt Book
package.name = debtbook
package.domain = org.zhoob
version = 17.0

# ---- Files ----
# All python files are in ONE folder (the repo root), so source.dir is "."
# Only .py files are packed: the font is NOT bundled, the app downloads it
# from Telegram on first launch.
source.dir = .
source.include_exts = py
source.exclude_dirs = .github, .git, bin, .buildozer, __pycache__

# ---- Libraries ----
# certifi : needed so HTTPS to Telegram works on Android
# pillow  : draws invoices / receipts as PNG and PDF
# pyjnius + android : share through WhatsApp
requirements = python3,kivy,pillow,pyjnius,android,openssl,certifi

# ---- Screen ----
orientation = portrait
fullscreen = 0

# ---- Android ----
# Internet only. No storage permissions are needed.
android.permissions = INTERNET
# Both CPU types so it also runs on old 32-bit phones.
# (API level and NDK are left at the defaults tested with the Buildozer release.)
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.allow_backup = True

[buildozer]
log_level = 2
# 0 = do not stop and ask when building as root inside GitHub
warn_on_root = 0
