# -*- coding: utf-8 -*-
"""الألوان والثيمات (فاتح / ليلي)."""

from kivy.core.window import Window


WHITE = (1, 1, 1, 1)


SOFT_WHITE = (1, 1, 1, 0.85)


GLASS = (1, 1, 1, 0.22)


_LIGHT = dict(
    PRIMARY=(0.09, 0.29, 0.49, 1),
    HEADER=(0.09, 0.29, 0.49, 1),
    TEXT=(0.12, 0.16, 0.24, 1),
    MUTED=(0.46, 0.51, 0.59, 1),
    BG=(0.95, 0.96, 0.98, 1),
    CARD=(1, 1, 1, 1),
    SOFT_BLUE=(0.90, 0.94, 0.99, 1),
    INPUT_BG=(0.985, 0.988, 0.995, 1),
    INPUT_BORDER=(0.80, 0.83, 0.88, 1),
    HINT=(0.62, 0.65, 0.70, 1),
    BORDER=(0.90, 0.92, 0.95, 1),
    RED=(0.80, 0.22, 0.22, 1),
    INV_RED=(0.86, 0.33, 0.30, 1),
    GREEN=(0.13, 0.60, 0.36, 1),
    ORANGE=(0.92, 0.55, 0.12, 1),
    BLUE=(0.18, 0.47, 0.80, 1),
    GRAY_BTN=(0.45, 0.47, 0.52, 1),
)


_DARK = dict(
    PRIMARY=(0.49, 0.74, 1.00, 1),
    HEADER=(0.09, 0.15, 0.27, 1),
    TEXT=(0.91, 0.93, 0.97, 1),
    MUTED=(0.58, 0.65, 0.76, 1),
    BG=(0.043, 0.059, 0.098, 1),
    CARD=(0.078, 0.102, 0.157, 1),
    SOFT_BLUE=(0.11, 0.17, 0.29, 1),
    INPUT_BG=(0.055, 0.075, 0.12, 1),
    INPUT_BORDER=(0.20, 0.26, 0.37, 1),
    HINT=(0.40, 0.47, 0.58, 1),
    BORDER=(0.15, 0.20, 0.30, 1),
    RED=(0.90, 0.33, 0.35, 1),
    INV_RED=(0.90, 0.35, 0.38, 1),
    GREEN=(0.16, 0.66, 0.45, 1),
    ORANGE=(0.95, 0.60, 0.18, 1),
    BLUE=(0.27, 0.54, 0.93, 1),
    GRAY_BTN=(0.26, 0.31, 0.41, 1),
)


THEMES = {"light": _LIGHT, "dark": _DARK}


CURRENT_THEME = "light"


# أسماء الألوان (القيم الابتدائية = الثيم الفاتح)
PRIMARY = _LIGHT["PRIMARY"]
HEADER = _LIGHT["HEADER"]
TEXT = _LIGHT["TEXT"]
MUTED = _LIGHT["MUTED"]
BG = _LIGHT["BG"]
CARD = _LIGHT["CARD"]
SOFT_BLUE = _LIGHT["SOFT_BLUE"]
INPUT_BG = _LIGHT["INPUT_BG"]
INPUT_BORDER = _LIGHT["INPUT_BORDER"]
HINT = _LIGHT["HINT"]
BORDER = _LIGHT["BORDER"]
RED = _LIGHT["RED"]
INV_RED = _LIGHT["INV_RED"]
GREEN = _LIGHT["GREEN"]
ORANGE = _LIGHT["ORANGE"]
BLUE = _LIGHT["BLUE"]
GRAY_BTN = _LIGHT["GRAY_BTN"]


# قواميس globals() للملفات التي تستخدم الألوان. عند تبديل الثيم نحدّث
# ألوان كل ملف منها (لأن "from theme import PRIMARY" ينسخ القيمة مرة واحدة).
_REGISTRY = []


def register_theme(module_globals):
    """كل ملف يستخدم الألوان يستدعي: register_theme(globals())"""
    if not any(g is module_globals for g in _REGISTRY):
        _REGISTRY.append(module_globals)
    module_globals.update(THEMES[CURRENT_THEME])


def is_dark():
    return CURRENT_THEME == "dark"


def apply_theme(name):
    global CURRENT_THEME
    CURRENT_THEME = name if name in THEMES else "light"
    colors = THEMES[CURRENT_THEME]
    globals().update(colors)
    for g in list(_REGISTRY):
        g.update(colors)
    try:
        Window.clearcolor = colors["BG"]
    except Exception:
        pass


apply_theme("light")


AVATAR_COLORS = [
    (0.18, 0.47, 0.80, 1),
    (0.55, 0.36, 0.75, 1),
    (0.13, 0.60, 0.36, 1),
    (0.92, 0.55, 0.12, 1),
    (0.80, 0.30, 0.45, 1),
    (0.10, 0.58, 0.64, 1),
]
