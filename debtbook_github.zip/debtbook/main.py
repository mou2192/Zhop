# -*- coding: utf-8 -*-
"""
نقطة بداية التطبيق (Buildozer يبحث عن main.py تحديداً).
أي خطأ أثناء تحميل ملفات التطبيق يظهر على الشاشة بدل الإغلاق الصامت.
"""
import os
import sys
import traceback

_APP_DIR = os.path.dirname(os.path.abspath(__file__))
if _APP_DIR not in sys.path:
    sys.path.insert(0, _APP_DIR)

_startup_error = None
try:
    import crashlog
    crashlog.install()
except Exception:
    crashlog = None

try:
    from app import DebtBookApp
except Exception:
    _startup_error = traceback.format_exc()
    if crashlog:
        crashlog.write_crash(_startup_error)


def _run_error_app(text):
    """تطبيق بسيط جداً يعرض نص الخطأ (يعمل بدون أي ملف آخر من التطبيق)."""
    from kivy.app import App
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.label import Label
    from kivy.uix.scrollview import ScrollView

    class ErrorApp(App):
        def build(self):
            box = BoxLayout(orientation="vertical", padding=12, spacing=8)
            box.add_widget(Label(text="Startup error - send a screenshot",
                                 color=(1, 0.4, 0.4, 1), size_hint_y=None,
                                 height=40))
            sv = ScrollView()
            lbl = Label(text=text[-3500:], font_size=11, halign="left",
                        valign="top", size_hint_y=None)
            lbl.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))
            lbl.bind(texture_size=lambda w, v: setattr(w, "height", v[1]))
            sv.add_widget(lbl)
            box.add_widget(sv)
            return box

    ErrorApp().run()


def main():
    if _startup_error:
        _run_error_app(_startup_error)
        return
    try:
        DebtBookApp().run()
    except Exception:
        err = traceback.format_exc()
        if crashlog:
            crashlog.write_crash(err)
        raise


if __name__ == "__main__":
    main()
