# -*- coding: utf-8 -*-
"""
مسارات التطبيق.
لا يستورد هذا الملف Kivy عمداً، حتى يمكن استخدامه مبكراً جداً
(مثلاً لكتابة سجل الأعطال قبل أن يبدأ Kivy).
"""
import os

APP_DIR = os.path.dirname(os.path.abspath(__file__))

# نفس طريقة Kivy في اكتشاف أندرويد
IS_ANDROID = "ANDROID_ARGUMENT" in os.environ


def _data_dir():
    if IS_ANDROID:
        try:
            from android.storage import app_storage_path
            return app_storage_path()
        except Exception:
            pass
        private = os.environ.get("ANDROID_PRIVATE")
        if private:
            return private
    return APP_DIR


DATA_DIR = _data_dir()
DATA_FILE = os.path.join(DATA_DIR, "debtbook_data.json")
FONT_STORE = os.path.join(DATA_DIR, "dl_fonts")     # هنا يُحفظ font.otf وباقي الخطوط
DOC_DIR = os.path.join(DATA_DIR, "docs")
CRASH_LOG = os.path.join(DATA_DIR, "crash.log")

for _d in (DATA_DIR, FONT_STORE):
    try:
        os.makedirs(_d, exist_ok=True)
    except Exception:
        pass
