# -*- coding: utf-8 -*-
"""قاعدة البيانات فوق Telegram Bot API + قناة التحميلات (الخطوط)."""

import base64
import hashlib
import json
import os
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from datetime import datetime
from config import (CHUNK_SIZE, CLIENTS_CHANNEL_ID, DOWNLOADS_CHANNEL_ID,
    SEND_BOT_TOKEN, USERS_CHANNEL_ID)
from paths import FONT_STORE
from utils import looks_like_font


_SSL_CTX = None


def _ssl_context():
    """سياق SSL. على أندرويد لا توجد شهادات جذر افتراضية لبايثون،
    فنستخدم certifi (موجودة في requirements) وإلا السياق الافتراضي."""
    global _SSL_CTX
    if _SSL_CTX is None:
        ctx = None
        try:
            import certifi
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            try:
                ctx = ssl.create_default_context()
            except Exception:
                ctx = None
        _SSL_CTX = ctx or False
    return _SSL_CTX or None


def tg_api(token, method, params=None, timeout=20):
    url = f"https://api.telegram.org/bot{token}/{method}"
    try:
        if params:
            data = urllib.parse.urlencode(params).encode("utf-8")
            req = urllib.request.Request(url, data=data)
        else:
            req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout,
                                    context=_ssl_context()) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode("utf-8"))
        except Exception:
            return {"ok": False, "description": str(e)}
    except Exception as e:
        return {"ok": False, "description": str(e)}


def hash_password(password):
    return hashlib.sha256(("zhoob|" + password).encode("utf-8")).hexdigest()


class TgError(Exception):
    pass


class TgGone(TgError):
    """الملف المحفوظ في الفهرس لم يعد موجوداً في القناة."""


class TgDB:
    """
    قاعدة بيانات فوق Bot API بدون getUpdates (فلا شيء يُفرَّغ أبداً):

      القناة الخاصة:
        - رسالة #INDEX مثبّتة (pinned) فيها {email: message_id}
          تُقرأ بـ getChat من أي جهاز، في أي وقت، وبدون حذف شيء.
        - رسالة #USER:email لكل مستخدم فيها الاسم وهاش كلمة المرور
          وقائمة أرقام رسائل العملاء "cl".
      القناة العامة:
        - بيانات العملاء مضغوطة (zlib + base64) ومقسّمة على عدة رسائل.

      القراءة بالـ message_id تتم عبر forwardMessage (يرجع النص) ثم
      deleteMessage للنسخة المحوّلة، فلا يبقى أي أثر في القناة.
    """

    def __init__(self, token, users_ch, clients_ch, api=tg_api, sleep=time.sleep):
        self.token = token
        self.users_ch = str(users_ch)
        self.clients_ch = str(clients_ch)
        self._api = api
        self._sleep = sleep

    # ---------- طبقة الاتصال ----------
    def call(self, method, params=None):
        r = {}
        for attempt in range(4):
            r = self._api(self.token, method, params)
            if r.get("ok"):
                return r
            retry = (r.get("parameters") or {}).get("retry_after")
            if r.get("error_code") == 429 and retry:
                self._sleep(min(int(retry) + 1, 15))
                continue
            break
        return r

    @staticmethod
    def _err(r):
        return str(r.get("description") or r.get("error") or r)[:120]

    @staticmethod
    def _gone(r):
        d = str(r.get("description", "")).lower()
        return ("not found" in d or "can't be forwarded" in d
                or "message_id_invalid" in d or "message to edit" in d
                or "message to delete" in d or "message to forward" in d)

    def send(self, ch, text):
        r = self.call("sendMessage", {"chat_id": ch, "text": text,
                                      "disable_web_page_preview": "true"})
        if not r.get("ok"):
            raise TgError(self._err(r))
        return r["result"]["message_id"]

    def edit(self, ch, mid, text):
        """يرجع True لو نجح (أو لم يتغير النص)، False لو الرسالة غير موجودة."""
        r = self.call("editMessageText", {"chat_id": ch, "message_id": mid,
                                          "text": text,
                                          "disable_web_page_preview": "true"})
        if r.get("ok"):
            return True
        if "not modified" in str(r.get("description", "")).lower():
            return True
        if self._gone(r):
            return False
        raise TgError(self._err(r))

    def delete(self, ch, mid):
        r = self.call("deleteMessage", {"chat_id": ch, "message_id": mid})
        return bool(r.get("ok"))

    def read_message(self, ch, mid):
        """يقرأ نص رسالة بالـ id بدون أي تفريغ: forward ثم حذف النسخة."""
        r = self.call("forwardMessage", {"chat_id": ch, "from_chat_id": ch,
                                         "message_id": mid,
                                         "disable_notification": "true"})
        if not r.get("ok"):
            if self._gone(r):
                return None
            raise TgError(self._err(r))
        msg = r["result"]
        self.delete(ch, msg.get("message_id"))
        return msg.get("text")

    # ---------- الفهرس (الرسالة المثبّتة) ----------
    def read_index(self):
        """يرجع (message_id أو None, dict)."""
        r = self.call("getChat", {"chat_id": self.users_ch})
        if not r.get("ok"):
            raise TgError("تعذر الاتصال بالنت: ")
        pm = (r.get("result") or {}).get("pinned_message")
        if pm and (pm.get("text") or "").startswith("#INDEX"):
            try:
                body = pm["text"].split("\n", 1)[1]
                return pm["message_id"], json.loads(body)
            except Exception:
                return pm["message_id"], {}
        return None, {}

    def write_index(self, mid, idx):
        text = "#INDEX\n" + json.dumps(idx, ensure_ascii=False,
                                       separators=(",", ":"), sort_keys=True)
        if len(text) > 4000:
            raise TgError("وصلت القناة للحد الأقصى من الحسابات")
        if mid and self.edit(self.users_ch, mid, text):
            return mid
        new_mid = self.send(self.users_ch, text)
        r = self.call("pinChatMessage", {"chat_id": self.users_ch,
                                         "message_id": new_mid,
                                         "disable_notification": "true"})
        if not r.get("ok"):
            raise TgError("امنح البوت صلاحية تثبيت الرسائل في القناة الخاصة")
        return new_mid

    def _index_set(self, email, user_mid):
        mid, idx = self.read_index()
        idx[email] = user_mid
        self.write_index(mid, idx)

    def _index_remove(self, email):
        mid, idx = self.read_index()
        if email in idx:
            del idx[email]
            self.write_index(mid, idx)

    # ---------- المستخدمون ----------
    @staticmethod
    def _parse_json_text(text):
        return json.loads(text[text.index("{"):text.rindex("}") + 1])

    def get_user(self, email):
        """يرجع (record, user_mid) أو (None, None)."""
        email = email.strip().lower()
        _pin, idx = self.read_index()
        mid = idx.get(email)
        if mid:
            text = self.read_message(self.users_ch, mid)
            if text and text.startswith("#USER:"):
                try:
                    return self._parse_json_text(text), mid
                except Exception:
                    pass
        return self._legacy_find(email)

    def create_user(self, email, name, password, shop="", loc="", phone="",
                    dev_id="", dev_name=""):
        email = email.strip().lower()
        rec, _m = self.get_user(email)
        if rec:
            raise TgError("البريد مستخدم مسبقاً")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        rec = {"type": "user", "email": email, "name": name,
               "shop": shop, "loc": loc, "phone": phone,
               "pw": hash_password(password), "cl": [],
               "sv": 1,
               "dev": ({dev_id: {"n": dev_name, "t": now}} if dev_id else {}),
               "created": now}
        text = f"#USER:{email}\n" + json.dumps(rec, ensure_ascii=False)
        mid = self.send(self.users_ch, text)
        try:
            self._index_set(email, mid)
        except Exception:
            self.delete(self.users_ch, mid)
            raise
        return rec, mid

    def save_user(self, rec, mid):
        rec = {k: v for k, v in rec.items() if not k.startswith("_")}
        if rec.get("password") and not rec.get("pw"):      # ترقية حساب قديم
            rec["pw"] = hash_password(rec.pop("password"))
        rec.pop("password", None)
        text = f"#USER:{rec['email']}\n" + json.dumps(rec, ensure_ascii=False)
        if not self.edit(self.users_ch, mid, text):
            mid = self.send(self.users_ch, text)
            self._index_set(rec["email"], mid)
        return mid

    @staticmethod
    def check_password(rec, password):
        if rec.get("pw"):
            return rec["pw"] == hash_password(password)
        return rec.get("password") == password          # حسابات قديمة

    # ---------- العملاء ----------
    @staticmethod
    def _pack(data):
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":")).encode("utf-8")
        b64 = base64.b64encode(zlib.compress(raw, 9)).decode("ascii")
        return [b64[i:i + CHUNK_SIZE] for i in range(0, len(b64), CHUNK_SIZE)] or [""]

    def read_clients(self, rec):
        """يرجع (dict البيانات, قائمة نصوص الأجزاء). {} لو ما فيه شيء."""
        mids = rec.get("cl") or []
        if not mids:
            return {}, []
        parts, texts = [], []
        for m in mids:
            t = self.read_message(self.clients_ch, m)
            if t is None:
                raise TgError("جزء من بيانات العملاء مفقود في القناة")
            texts.append(t)
            parts.append(t.split("\n", 1)[1] if "\n" in t else "")
        try:
            raw = zlib.decompress(base64.b64decode("".join(parts)))
            return json.loads(raw.decode("utf-8")), texts
        except Exception:
            raise TgError("بيانات العملاء في القناة تالفة")

    def write_clients(self, rec, user_mid, data, old_texts=None):
        """يرفع data على أجزاء، ويحدّث رسائل الأجزاء الموجودة. يرجع rec المحدّث."""
        email = rec["email"]
        chunks = self._pack(data)
        total = len(chunks)
        old_mids = list(rec.get("cl") or [])
        old_texts = old_texts or []
        new_mids = []
        for i, ch in enumerate(chunks):
            text = f"#CL:{email}:{i + 1}/{total}\n{ch}"
            if i < len(old_mids):
                if i < len(old_texts) and old_texts[i] == text:
                    new_mids.append(old_mids[i])
                    continue
                if self.edit(self.clients_ch, old_mids[i], text):
                    new_mids.append(old_mids[i])
                    continue
            new_mids.append(self.send(self.clients_ch, text))
        for m in old_mids[total:]:
            self.delete(self.clients_ch, m)
        if new_mids != old_mids:
            rec = dict(rec)
            rec["cl"] = new_mids
            self.save_user(rec, user_mid)
        return rec

    # ---------- حذف الحساب ----------
    def delete_account(self, rec, user_mid):
        email = rec["email"]
        for m in rec.get("cl") or []:
            self.delete(self.clients_ch, m)
        self._index_remove(email)
        self.delete(self.users_ch, user_mid)

    # ---------- ترحيل الحسابات القديمة (قبل الفهرس) ----------
    def _legacy_find(self, email):
        """يبحث عن #USER:email القديمة عبر getUpdates بدون offset
        (لا تُفرّغ شيئاً)، وإن وجدها ينقلها للفهرس. يرجع (record, mid)."""
        try:
            r = self.call("getUpdates", {"limit": 100, "timeout": 0})
            if not r.get("ok"):
                return None, None
            users, clients = {}, {}
            for u in r.get("result", []):
                p = u.get("channel_post") or u.get("edited_channel_post")
                if not p:
                    continue
                txt = p.get("text") or ""
                chat = str((p.get("chat") or {}).get("id"))
                if txt.startswith("#USER:") and chat == self.users_ch:
                    users[txt.split("\n", 1)[0][6:].strip().lower()] = (txt, p["message_id"])
                elif txt.startswith("#CLIENTS:") and chat == self.clients_ch:
                    clients[txt.split("\n", 1)[0][9:].strip().lower()] = (txt, p["message_id"])
            if email not in users:
                return None, None
            txt, mid = users[email]
            rec = self._parse_json_text(txt)
            rec.setdefault("cl", [])
            rec["email"] = email
            if email in clients:
                ctxt, cmid = clients[email]
                try:
                    rec["_legacy_clients"] = self._parse_json_text(ctxt)
                    rec["_legacy_clients_mid"] = cmid
                except Exception:
                    pass
            try:
                self._index_set(email, mid)
            except Exception as e:
                print(f"[LEGACY INDEX] {e}")
            return rec, mid
        except Exception as e:
            print(f"[LEGACY] {e}")
            return None, None


DB = TgDB(SEND_BOT_TOKEN, USERS_CHANNEL_ID, CLIENTS_CHANNEL_ID)


def dl_probe(mid):
    """يقرأ بيانات الملف في الرسالة mid بدون أي أثر. يرجع (gone, doc)."""
    r = DB.call("forwardMessage", {"chat_id": DB.users_ch,
                                   "from_chat_id": DOWNLOADS_CHANNEL_ID,
                                   "message_id": mid,
                                   "disable_notification": "true"})
    if not r.get("ok"):
        d = str(r.get("description", "")).lower()
        if ("chat not found" in d or "not a member" in d
                or r.get("error_code") in (401, 403)):
            raise TgError("تعذر الوصول إلى الخطوط المتاحة")
        if r.get("error_code") == 429 or "retry" in d:
            raise TgError("تعذر الاتصال، حاول لاحقاً")
        if DB._gone(r) or r.get("error_code") == 400:
            return True, None
        raise TgError(DB._err(r))
    msg = r["result"]
    DB.delete(DB.users_ch, msg.get("message_id"))
    return False, (msg.get("document") or {})


def scan_downloads(catalog, tolerance=25):
    """يمسح الرسائل الجديدة ويضيف الملفات للفهرس المحلي (تراكمي)."""
    items = catalog.setdefault("items", {})
    mid = int(catalog.get("last", 0))
    newest = mid
    misses = 0
    while misses < tolerance:
        mid += 1
        gone, doc = dl_probe(mid)
        if gone:
            misses += 1
            continue
        misses = 0
        newest = mid
        if doc and doc.get("file_name"):
            items[doc["file_name"]] = {"mid": mid,
                                       "size": int(doc.get("file_size") or 0)}
    catalog["last"] = newest
    return catalog


def find_download(catalog, name, tolerance=25, on_progress=None):
    """يبحث عن ملف باسمه في قناة التحميلات ويتوقف فور إيجاده.
    يحدّث الفهرس المحلي تراكمياً. يرجع بيانات الملف، أو None لو لم يُوجد."""
    items = catalog.setdefault("items", {})
    if name in items:
        return items[name]
    mid = int(catalog.get("last", 0))
    misses = 0
    while misses < tolerance:
        mid += 1
        if on_progress:
            try:
                on_progress(mid)
            except Exception:
                pass
        gone, doc = dl_probe(mid)
        if gone:
            misses += 1
            continue
        misses = 0
        catalog["last"] = mid
        if doc and doc.get("file_name"):
            items[doc["file_name"]] = {"mid": mid,
                                       "size": int(doc.get("file_size") or 0)}
            if doc["file_name"] == name:
                return items[name]
    return None


def download_font(name, item):
    """ينزّل الخط إلى FONT_STORE. لا يسجّله في Kivy (التسجيل يتم في الخيط
    الرئيسي بعد انتهاء التحميل عبر register_user_fonts)."""
    gone, doc = dl_probe(int(item["mid"]))
    if gone or not doc or doc.get("file_name") != name:
        raise TgGone("الخط غير متاح حالياً")
    r = DB.call("getFile", {"file_id": doc["file_id"]})
    if not r.get("ok"):
        raise TgError("تعذر تحميل الخط")
    url = "https://api.telegram.org/file/bot%s/%s" % (
        DB.token, r["result"]["file_path"])
    os.makedirs(FONT_STORE, exist_ok=True)
    tmp = os.path.join(FONT_STORE, name + ".part")
    final = os.path.join(FONT_STORE, name)
    with urllib.request.urlopen(url, timeout=60,
                                context=_ssl_context()) as resp, \
            open(tmp, "wb") as f:
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            f.write(chunk)
    if os.path.getsize(tmp) < 1000 or not looks_like_font(tmp):
        os.remove(tmp)
        raise TgError("الملف غير صالح")
    os.replace(tmp, final)
    return final
