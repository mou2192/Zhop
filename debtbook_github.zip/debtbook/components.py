# -*- coding: utf-8 -*-
"""عناصر جاهزة: صف صنف، نموذج إضافة صنف، بطاقة فاتورة، صف عميل."""

from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.widget import Widget
from theme import (BLUE, GRAY_BTN, GREEN, INV_RED, MUTED, PRIMARY, RED, SOFT_WHITE,
    TEXT, WHITE, register_theme)
from utils import money, money_signed
from widgets import Avatar, CardBox, make_arabic_popup, mk_btn, mk_input, mk_text

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


def item_total(it):
    gross = it.get("qty", 1) * it.get("price", 0)
    return max(0, gross - it.get("discount", 0))


def make_item_row(item, on_delete=None, show_qty=True):
    name = item.get("name", "")
    qty = item.get("qty", 1)
    note = item.get("note", "")
    disc = item.get("discount", 0)
    total = item_total(item)

    row = CardBox(orientation="horizontal", size_hint_y=None, height=dp(64),
                  padding=[dp(12), dp(6)], spacing=dp(8), radius=dp(12))
    if on_delete is not None:
        del_btn = mk_btn("X", size_hint=(None, None), size=(dp(38), dp(38)),
                         background_color=RED, font_size=dp(15),
                         pos_hint={"center_y": 0.5})
        del_btn.bind(on_release=lambda *a: on_delete())
        row.add_widget(del_btn)

    total_col = BoxLayout(orientation="vertical", size_hint_x=None, width=dp(96))
    total_col.add_widget(mk_text(money(total), dp(16), PRIMARY,
                                 halign="left", hint_y=0.58))
    total_col.add_widget(mk_text("ريال", dp(11), MUTED,
                                 halign="left", hint_y=0.42))
    row.add_widget(total_col)

    name_col = BoxLayout(orientation="vertical")
    name_col.add_widget(mk_text(name, dp(15), TEXT, hint_y=0.58))
    if show_qty:
        sub = f"العدد: {qty:g}"
        if disc:
            sub += f" - خصم: {money(disc)}"
        if note:
            sub += f" - {note}"
        name_col.add_widget(mk_text(sub, dp(12), MUTED, hint_y=0.42))
    row.add_widget(name_col)
    return row


def build_item_form(on_add):
    row1 = BoxLayout(size_hint_y=None, height=dp(72), spacing=dp(10))
    ncol = BoxLayout(orientation="vertical", spacing=dp(4))
    ncol.add_widget(mk_text("اسم الصنف", dp(13), MUTED, height=dp(20)))
    name_in = mk_input(hint_text="اكتب هنا الصنف", size_hint_y=None, height=dp(46))
    ncol.add_widget(name_in)
    row1.add_widget(ncol)

    row2 = BoxLayout(size_hint_y=None, height=dp(72), spacing=dp(10))
    pcol = BoxLayout(orientation="vertical", spacing=dp(4))
    pcol.add_widget(mk_text("السعر", dp(13), MUTED, height=dp(20)))
    price_in = mk_input(hint_text="0", input_filter="float",
                        size_hint_y=None, height=dp(46))
    pcol.add_widget(price_in)
    qcol = BoxLayout(orientation="vertical", spacing=dp(4))
    qcol.add_widget(mk_text("الكمية", dp(13), MUTED, height=dp(20)))
    qty_in = mk_input(hint_text="1", input_filter="float",
                      size_hint_y=None, height=dp(46))
    qcol.add_widget(qty_in)
    row2.add_widget(pcol)
    row2.add_widget(qcol)

    row3 = BoxLayout(size_hint_y=None, height=dp(72), spacing=dp(10))
    dcol = BoxLayout(orientation="vertical", spacing=dp(4))
    dcol.add_widget(mk_text("الخصم )مبلغ يُخصم من مجموع الصنف(",
                            dp(13), MUTED, height=dp(20)))
    disc_in = mk_input(hint_text="0", input_filter="float",
                       size_hint_y=None, height=dp(46))
    dcol.add_widget(disc_in)
    row3.add_widget(dcol)

    row4 = BoxLayout(size_hint_y=None, height=dp(72), spacing=dp(10))
    note_col = BoxLayout(orientation="vertical", spacing=dp(4))
    note_col.add_widget(mk_text("ملاحظة )اختياري(", dp(13), MUTED,
                                height=dp(20)))
    note_in = mk_input(hint_text="اكتب هنا الملاحظه",
                       size_hint_y=None, height=dp(46))
    note_col.add_widget(note_in)
    row4.add_widget(note_col)

    total_height = dp(72 * 4) + dp(46) + dp(10) + dp(20)
    card = CardBox(orientation="vertical", size_hint_y=None,
                   height=total_height,
                   padding=[dp(12), dp(10), dp(12), dp(12)], spacing=dp(6))
    card.add_widget(row1)
    card.add_widget(row2)
    card.add_widget(row3)
    card.add_widget(row4)
    add_btn = mk_btn("+ إضافة الصنف", height=dp(46), background_color=BLUE)
    add_btn.bind(on_release=lambda *a: on_add())
    card.add_widget(add_btn)
    return card, name_in, qty_in, price_in, note_in, disc_in


def parse_item(name_in, qty_in, price_in, note_in=None, disc_in=None):
    name = name_in.text.strip()
    try:
        qty = float(qty_in.text.strip() or "1")
    except ValueError:
        qty = 1
    try:
        price = float(price_in.text.strip() or "0")
    except ValueError:
        price = 0
    try:
        disc = float(disc_in.text.strip() or "0") if disc_in is not None else 0
    except ValueError:
        disc = 0
    disc = max(0, disc)
    if not name or price <= 0 or qty <= 0:
        return None
    if disc > qty * price:
        box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(10))
        box.add_widget(mk_text("الخصم أكبر من مجموع الصنف", dp(16), RED,
                               halign="center", height=dp(36)))
        box.add_widget(mk_text(f"مجموع الصنف: {money(qty * price)}",
                               dp(14), MUTED,
                               halign="center", height=dp(28)))
        box.add_widget(Widget())
        ok = mk_btn("حسناً", height=dp(46), background_color=GRAY_BTN)
        box.add_widget(ok)
        pop = make_arabic_popup("تنبيه", box, size_hint=(0.85, 0.36),
                                title_color=RED, separator_color=RED)
        ok.bind(on_release=lambda *a: pop.dismiss())
        pop.open()
        return None
    note = note_in.text.strip() if note_in is not None else ""
    name_in.text = ""
    qty_in.text = ""
    price_in.text = ""
    if disc_in is not None:
        disc_in.text = ""
    if note_in is not None:
        note_in.text = ""
    item = {"name": name, "qty": qty, "price": price}
    if disc:
        item["discount"] = disc
    if note:
        item["note"] = note
    return item


def make_invoice_card(inv, on_tap):
    kind = inv.get("kind", "فاتورة")
    total = inv.get("total", 0)
    date = inv.get("date", "")
    items = inv.get("items", [])
    color = INV_RED if kind == "فاتورة" else GREEN

    card = CardBox(orientation="vertical", size_hint_y=None, height=dp(112),
                   padding=0, spacing=0, on_tap=on_tap, radius=dp(14))
    head = BoxLayout(size_hint_y=None, height=dp(34),
                     padding=[dp(14), 0], spacing=dp(6))
    with head.canvas.before:
        Color(*color)
        head_rect = RoundedRectangle(pos=head.pos, size=head.size,
                                     radius=[dp(14), dp(14), 0, 0])

    def _uh(*a):
        head_rect.pos = head.pos
        head_rect.size = head.size
    head.bind(pos=_uh, size=_uh)
    head.add_widget(mk_text(date, dp(12), SOFT_WHITE,
                            halign="left", hint_x=0.55))
    head.add_widget(mk_text(kind, dp(15), WHITE,
                            halign="right", hint_x=0.45))
    card.add_widget(head)

    body = BoxLayout(orientation="vertical", padding=[dp(14), dp(6)], spacing=0)
    body.add_widget(mk_text(f"{money(total)} ريال", dp(22), color,
                            height=dp(38)))
    sub = BoxLayout(size_hint_y=None, height=dp(28), spacing=dp(6))
    if kind == "فاتورة":
        sub_text = f"عدد الأصناف: {len(items)}"
    else:
        sub_text = items[0].get("name", "") if items else ""
    sub.add_widget(mk_text("عرض التفاصيل", dp(12), BLUE,
                           halign="left", hint_x=0.4))
    sub.add_widget(mk_text(sub_text, dp(13), MUTED,
                           halign="right", hint_x=0.6))
    body.add_widget(sub)
    card.add_widget(body)
    return card


def make_client_row(client, on_tap):
    name = client.get("name", "بدون اسم")
    phone = client.get("phone", "") or "بدون رقم"
    bal = client.get("balance", 0)
    if bal > 0:
        amount_color = RED
        status = "عليه دين"
    elif bal < 0:
        amount_color = GREEN
        status = "له رصيد"
    else:
        amount_color = GREEN
        status = "لا يوجد دين"

    row = CardBox(orientation="horizontal", size_hint_y=None, height=dp(78),
                  padding=[dp(12), dp(8)], spacing=dp(10), on_tap=on_tap)
    left = BoxLayout(orientation="vertical", size_hint_x=None, width=dp(118))
    left.add_widget(mk_text(f"{money_signed(bal)} ريال", dp(16), amount_color,
                            halign="left", hint_y=0.55))
    left.add_widget(mk_text(status, dp(12), MUTED,
                            halign="left", hint_y=0.45))
    row.add_widget(left)
    mid = BoxLayout(orientation="vertical")
    mid.add_widget(mk_text(name, dp(17), TEXT, hint_y=0.55))
    mid.add_widget(mk_text(phone, dp(12), MUTED, hint_y=0.45))
    row.add_widget(mid)
    av = Avatar(name)
    av.pos_hint = {"center_y": 0.5}
    row.add_widget(av)
    return row
