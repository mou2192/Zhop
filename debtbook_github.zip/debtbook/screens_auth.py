# -*- coding: utf-8 -*-
"""شاشات: تسجيل الدخول، إنشاء حساب، شروط الاستخدام."""

import re
import textwrap
import threading
from kivy.clock import Clock
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.screenmanager import Screen
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from terms_text import TERMS_TEXT
from theme import (BLUE, GLASS, GRAY_BTN, GREEN, HEADER, MUTED, RED, SOFT_WHITE, TEXT,
    WHITE, register_theme)
from widgets import DrawnText, make_header, mk_btn, mk_input, mk_text

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


class LoginScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.build_ui()

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)

        head = FloatLayout(size_hint_y=None, height=dp(200))
        with head.canvas.before:
            Color(*HEADER)
            head_rect = RoundedRectangle(pos=head.pos, size=head.size,
                                         radius=[0, 0, dp(30), dp(30)])

        def _uh(*a):
            head_rect.pos = head.pos
            head_rect.size = head.size
        head.bind(pos=_uh, size=_uh)

        t = DrawnText(text="دفتر ديون الزهوب",
                      font_size=dp(26), color=WHITE, halign="center",
                      size_hint=(1, 1), pos_hint={"x": 0, "y": 0.65})
        t.disabled = True
        head.add_widget(t)

        st = DrawnText(text="سجل دخولك للمتابعة",
                       font_size=dp(14), color=SOFT_WHITE, halign="center",
                       size_hint=(1, 1), pos_hint={"x": 0, "y": 0.35})
        st.disabled = True
        head.add_widget(st)
        if getattr(self.app, "_adding", False):
            cb = mk_btn("إلغاء", size_hint=(None, None),
                        size=(dp(76), dp(38)), font_size=dp(14),
                        background_color=GLASS,
                        pos_hint={"x": 0.03, "top": 0.95})
            cb.bind(on_release=lambda *a: self.app.cancel_add_account())
            head.add_widget(cb)
        root.add_widget(head)

        body = BoxLayout(orientation="vertical", spacing=dp(10),
                         padding=[dp(24), dp(24), dp(24), dp(20)])

        body.add_widget(mk_text("البريد الإلكتروني", dp(13), MUTED,
                                height=dp(22)))
        self.email_in = mk_input(hint_text="example@mail.com",
                                 size_hint_y=None, height=dp(50))
        body.add_widget(self.email_in)

        body.add_widget(mk_text("كلمة المرور", dp(13), MUTED, height=dp(22)))
        self.pass_in = mk_input(hint_text="********",
                                size_hint_y=None, height=dp(50))
        body.add_widget(self.pass_in)

        self.msg_dt = mk_text("", dp(13), RED, halign="center", height=dp(28))
        body.add_widget(self.msg_dt)

        body.add_widget(Widget(size_hint_y=None, height=dp(8)))

        login_btn = mk_btn("دخول", height=dp(52), font_size=dp(18),
                           background_color=GREEN)
        login_btn.bind(on_release=self.do_login)
        body.add_widget(login_btn)

        reg_btn = mk_btn("تسجيل بحساب جديد", height=dp(48), font_size=dp(15),
                         background_color=GRAY_BTN)
        reg_btn.bind(on_release=lambda *a: self.app.go_register())
        body.add_widget(reg_btn)

        body.add_widget(Widget())
        root.add_widget(body)
        self.add_widget(root)

    def do_login(self, *a):
        email = self.email_in.text.strip().lower()
        password = self.pass_in.text.strip()
        if not email or not password:
            self.msg_dt.text = "الرجاء إدخال البريد وكلمة المرور"
            return
        self.msg_dt.text = "جاري التحقق..."
        self.msg_dt.text = self.msg_dt.text  # forced redraw

        def worker():
            ok, data = self.app.verify_login(email, password)
            Clock.schedule_once(lambda dt: self._on_result(ok, data), 0)

        threading.Thread(target=worker, daemon=True).start()

    def _on_result(self, ok, data):
        if ok:
            self.msg_dt.text = ""
            self.app.on_login_success(data)
        else:
            self.msg_dt.text = data or "فشل التحقق"


class RegisterScreen(Screen):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.agreed = False
        self.build_ui()

    def _field(self, body, label, hint, **kw):
        body.add_widget(mk_text(label, dp(13), MUTED, height=dp(22)))
        w = mk_input(hint_text=hint, size_hint_y=None, height=dp(50), **kw)
        body.add_widget(w)
        return w

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        head = make_header("حساب جديد", HEADER,
                           on_back=lambda *a: self.app.go_login())
        root.add_widget(head)

        sv = ScrollView(size_hint=(1, 1))
        body = BoxLayout(orientation="vertical", spacing=dp(8),
                         padding=[dp(24), dp(16), dp(24), dp(20)],
                         size_hint_y=None)
        body.bind(minimum_height=body.setter("height"))

        self.name_in = self._field(body, "الاسم الرباعي", "الاسم الكامل )أربعة أسماء(")
        self.shop_in = self._field(body, "اسم المشروع أو اسم الدكان", "مثال: بقالة النور")
        self.loc_in = self._field(body, "موقع الدكان )المنطقة(", "المنطقة التي يوجد فيها الدكان")
        self.phone_in = self._field(body, "رقم التاجر", "771234567", input_filter="int")
        self.email_in = self._field(body, "البريد الإلكتروني (Gmail)", "example@gmail.com")
        self.pass_in = self._field(body, "كلمة المرور", "********")
        self.confirm_in = self._field(body, "تأكيد كلمة المرور", "********")

        # ---- الموافقة على شروط الاستخدام ----
        body.add_widget(Widget(size_hint_y=None, height=dp(4)))
        self.terms_btn = mk_btn("شروط الاستخدام )اضغط للقراءة والموافقة(",
                                height=dp(48), font_size=dp(15),
                                background_color=BLUE)
        self.terms_btn.bind(on_release=lambda *a: self.app.open_terms())
        body.add_widget(self.terms_btn)
        self.terms_state = mk_text("لم تتم الموافقة على شروط الاستخدام بعد",
                                   dp(12), RED, halign="center", height=dp(26))
        body.add_widget(self.terms_state)

        self.msg_dt = mk_text("", dp(13), RED, halign="center", height=dp(28))
        body.add_widget(self.msg_dt)

        self.save_btn = mk_btn("تسجيل", height=dp(52), font_size=dp(18),
                               background_color=GRAY_BTN)
        self.save_btn.disabled = True
        self.save_btn.bind(on_release=self.do_register)
        body.add_widget(self.save_btn)

        sv.add_widget(body)
        root.add_widget(sv)
        self.add_widget(root)
        if self.agreed:
            self.set_agreed()

    def set_agreed(self):
        self.agreed = True
        self.save_btn.disabled = False
        self.save_btn.set_bg(GREEN)
        self.terms_state._color = tuple(GREEN)
        self.terms_state.text = "تمت الموافقة على شروط الاستخدام"

    def do_register(self, *a):
        name = self.name_in.text.strip()
        shop = self.shop_in.text.strip()
        loc = self.loc_in.text.strip()
        phone = self.phone_in.text.strip()
        email = self.email_in.text.strip().lower()
        password = self.pass_in.text.strip()
        confirm = self.confirm_in.text.strip()

        if len(name.split()) < 4:
            self.msg_dt.text = "الرجاء إدخال الاسم الرباعي كاملاً"
            return
        if not shop:
            self.msg_dt.text = "أدخل اسم المشروع أو الدكان"
            return
        if not loc:
            self.msg_dt.text = "أدخل موقع الدكان"
            return
        if len(phone) < 7:
            self.msg_dt.text = "أدخل رقم التاجر بشكل صحيح"
            return
        if not re.fullmatch(r"[a-z0-9._+\-]+@gmail\.com", email):
            self.msg_dt.text = "يجب أن يكون البريد من نوع @gmail.com"
            return
        if len(password) < 4:
            self.msg_dt.text = "كلمة المرور قصيرة جداً"
            return
        if password != confirm:
            self.msg_dt.text = "كلمتا المرور غير متطابقتين"
            return
        if not self.agreed:
            self.msg_dt.text = "يجب الموافقة على شروط الاستخدام"
            return

        self.msg_dt.text = "جاري التسجيل..."

        def worker():
            ok, msg = self.app.do_register(name, email, password,
                                           shop, loc, phone)
            Clock.schedule_once(
                lambda dt: self._on_result(ok, msg, email, name,
                                           shop, loc, phone), 0)

        threading.Thread(target=worker, daemon=True).start()

    def _on_result(self, ok, msg, email, name, shop, loc, phone):
        if ok:
            self.msg_dt.text = ""
            self.app.on_register_success(email, name, shop, loc, phone)
        else:
            self.msg_dt.text = msg or "فشل التسجيل"


class TermsScreen(Screen):
    """صفحة شروط الاستخدام الكاملة. زر \"أوافق\" يتفعّل عند الوصول للنهاية."""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.can_agree = False
        self.build_ui()

    @staticmethod
    def _wrap(text, width=34):
        out = []
        for para in text.strip().split("\n"):
            para = para.strip()
            if not para:
                out.append("")
                continue
            out.extend(textwrap.wrap(para, width=width) or [""])
        return out

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header("شروط الاستخدام", HEADER,
                                    on_back=lambda *a: self.app.terms_back()))
        self.scroll = ScrollView(size_hint=(1, 1), bar_width=dp(4))
        self.lay = GridLayout(cols=1, spacing=dp(2), size_hint_y=None,
                              padding=[dp(14), dp(12), dp(14), dp(16)])
        self.lay.bind(minimum_height=self.lay.setter("height"))
        for line in self._wrap(TERMS_TEXT):
            if line:
                self.lay.add_widget(mk_text(line, dp(15), TEXT, height=dp(28)))
            else:
                self.lay.add_widget(Widget(size_hint_y=None, height=dp(12)))
        self.scroll.add_widget(self.lay)
        root.add_widget(self.scroll)

        bar = BoxLayout(orientation="vertical", size_hint_y=None,
                        height=dp(96), padding=[dp(14), dp(6), dp(14), dp(10)],
                        spacing=dp(4))
        self.hint = mk_text("اقرأ الشروط حتى النهاية لتفعيل زر الموافقة",
                            dp(12), MUTED, halign="center", height=dp(22))
        bar.add_widget(self.hint)
        self.agree_btn = mk_btn("أوافق", height=dp(52), font_size=dp(18),
                                background_color=GRAY_BTN)
        self.agree_btn.disabled = True
        self.agree_btn.bind(on_release=lambda *a: self.app.terms_agreed())
        bar.add_widget(self.agree_btn)
        root.add_widget(bar)
        self.add_widget(root)

        self.scroll.bind(scroll_y=self._check, height=self._check)
        self.lay.bind(height=self._check)
        Clock.schedule_once(self._check, 0.5)

    def _check(self, *a):
        if self.can_agree:
            return
        if (self.lay.height <= self.scroll.height + dp(6)
                or self.scroll.scroll_y <= 0.03):
            self.can_agree = True
            self.agree_btn.disabled = False
            self.agree_btn.set_bg(GREEN)
            self.hint.text = "يمكنك الآن الموافقة"
