# -*- coding: utf-8 -*-
"""شاشات: العميل، إضافة فاتورة، إضافة سند، تفاصيل الفاتورة."""

from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import Screen
from kivy.uix.widget import Widget
from components import (build_item_form, item_total, make_invoice_card, make_item_row,
    parse_item)
from documents import show_document_popup
from theme import (BLUE, GLASS, GRAY_BTN, GREEN, HEADER, INV_RED, MUTED, ORANGE,
    PRIMARY, RED, SOFT_BLUE, SOFT_WHITE, TEXT, WHITE, register_theme)
from utils import gen_id, money, money_signed, now_full, now_str
from widgets import (CardBox, make_arabic_popup, make_body, make_header,
    make_scroll_list, mk_btn, mk_input, mk_text, schedule_refresh)

# يحدّث ألوان هذا الملف تلقائياً عند تبديل الثيم
register_theme(globals())


class ClientScreen(Screen):
    def __init__(self, app, client_index, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.client_index = client_index
        self.build_ui()
        self.refresh()

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header("بيانات العميل", HEADER,
                                    on_back=lambda *a: self.app.go_main()))

        info = BoxLayout(orientation="vertical", size_hint_y=None,
                         height=dp(150),
                         padding=[dp(12), dp(8), dp(12), dp(12)], spacing=dp(4))
        with info.canvas.before:
            Color(*HEADER)
            info_rect = RoundedRectangle(pos=info.pos, size=info.size,
                                         radius=[0, 0, dp(22), dp(22)])

        def _ui(*a):
            info_rect.pos = info.pos
            info_rect.size = info.size
        info.bind(pos=_ui, size=_ui)

        top = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        self.name_dt = mk_text("", dp(21), WHITE, halign="right")
        top.add_widget(self.name_dt)
        edit_btn = mk_btn("تعديل", size_hint=(None, None),
                          size=(dp(64), dp(36)), font_size=dp(13),
                          background_color=GLASS,
                          pos_hint={"center_y": 0.5})
        edit_btn.bind(on_release=self.edit_client_data)
        top.add_widget(edit_btn)
        info.add_widget(top)

        self.phone_dt = mk_text("", dp(13), (0.85, 0.91, 0.98, 1),
                                halign="right", height=dp(22))
        info.add_widget(self.phone_dt)

        bal_box = CardBox(orientation="vertical", size_hint_y=None,
                          height=dp(70), padding=[dp(14), dp(4)], spacing=0,
                          bg=(1, 1, 1, 0.16), shadow=False, radius=dp(14))
        bal_box.add_widget(mk_text("الرصيد المستحق", dp(12), SOFT_WHITE,
                                   height=dp(20)))
        self.balance_dt = mk_text("", dp(24), (1, 0.93, 0.65, 1), hint_y=1)
        bal_box.add_widget(self.balance_dt)
        info.add_widget(bal_box)
        root.add_widget(info)

        body = make_body(padding=[dp(12), dp(6), dp(12), dp(10)])
        body.spacing = dp(8)

        actions = BoxLayout(size_hint_y=None, height=dp(62), spacing=dp(8))
        specs = [
            ("إضافة\nفاتورة", ORANGE,
             lambda *a: self.app.open_add_invoice_screen(self.client_index)),
            ("سند\nقبض", GREEN,
             lambda *a: self.app.open_add_receipt_screen(self.client_index)),
            ("إرسال\nالدين", BLUE, self.send_debt_whatsapp),
            ("حذف\nالعميل", RED, self.confirm_delete),
        ]
        for label, col, cb in specs:
            b = mk_btn(label, height=dp(62), font_size=dp(13),
                       background_color=col)
            b.bind(on_release=cb)
            actions.add_widget(b)
        body.add_widget(actions)

        sec = BoxLayout(size_hint_y=None, height=dp(28))
        self.count_dt = mk_text("", dp(12), MUTED, halign="left", hint_x=0.35)
        sec.add_widget(self.count_dt)
        sec.add_widget(mk_text("الفواتير والسندات", dp(16), PRIMARY,
                               hint_x=0.65))
        body.add_widget(sec)

        scroll, self.invoices_layout = make_scroll_list()
        body.add_widget(scroll)
        root.add_widget(body)
        self.add_widget(root)

    def refresh(self):
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        c = clients[self.client_index]
        self.name_dt.text = c.get("name", "بدون اسم")
        self.phone_dt.text = "الرقم: " + (c.get("phone", "") or "غير محدد")
        bal = c.get("balance", 0)
        self.balance_dt.text = f"{money_signed(bal)} ريال"

        self.invoices_layout.clear_widgets()
        invoices = c.get("invoices", [])
        self.count_dt.text = f"{len(invoices)} عملية"
        if not invoices:
            empty = BoxLayout(orientation="vertical", size_hint_y=None,
                              height=dp(90))
            empty.add_widget(mk_text("لا توجد فواتير بعد", dp(16), MUTED,
                                     halign="center", hint_y=0.5))
            empty.add_widget(mk_text("اضغط على إضافة فاتورة للبدء", dp(13),
                                     MUTED, halign="center", hint_y=0.5))
            self.invoices_layout.add_widget(empty)
            return
        for real_i in range(len(invoices) - 1, -1, -1):
            inv = invoices[real_i]
            card = make_invoice_card(
                inv,
                on_tap=lambda idx=real_i: self.app.open_invoice_screen(
                    self.client_index, idx))
            self.invoices_layout.add_widget(card)

    def edit_client_data(self, *a):
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        c = clients[self.client_index]
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(10))
        content.add_widget(mk_text("اسم العميل", dp(13), MUTED, height=dp(22)))
        name_input = mk_input(size_hint_y=None, height=dp(48),
                              hint_text="الاسم الكامل")
        name_input.text = c.get("name", "")
        content.add_widget(name_input)
        content.add_widget(mk_text("رقم الواتساب", dp(13), MUTED,
                                   height=dp(22)))
        phone_input = mk_input(input_filter="int", size_hint_y=None,
                               height=dp(48), hint_text="0771234567")
        phone_input.text = c.get("phone", "")
        content.add_widget(phone_input)
        content.add_widget(Widget())
        btns = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(8))
        save_btn = mk_btn("حفظ", background_color=GREEN)
        cancel_btn = mk_btn("إلغاء", background_color=GRAY_BTN)
        btns.add_widget(save_btn)
        btns.add_widget(cancel_btn)
        content.add_widget(btns)
        popup = make_arabic_popup("تعديل بيانات العميل", content,
                                  size_hint=(0.92, 0.55))

        def do_save(*a):
            n = name_input.text.strip()
            if not n:
                return
            c["name"] = n
            c["phone"] = phone_input.text.strip()
            c["mod"] = now_full()
            self.app.save()
            self.refresh()
            popup.dismiss()

        save_btn.bind(on_release=do_save)
        cancel_btn.bind(on_release=lambda *a: popup.dismiss())
        popup.open()

    def send_debt_whatsapp(self, *a):
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        show_document_popup(clients[self.client_index], None, "statement")

    def confirm_delete(self, *a):
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        c = clients[self.client_index]
        content = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(12))
        content.add_widget(mk_text(f"هل تريد حذف العميل: {c.get('name','')} ؟",
                                   dp(16), TEXT, halign="center",
                                   height=dp(44)))
        content.add_widget(Widget())
        bb = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        yes = mk_btn("نعم", background_color=RED)
        no = mk_btn("إلغاء", background_color=GRAY_BTN)
        bb.add_widget(yes)
        bb.add_widget(no)
        content.add_widget(bb)
        popup = make_arabic_popup("تأكيد الحذف", content,
                                  size_hint=(0.88, 0.4),
                                  title_color=RED, separator_color=RED)

        def do_delete(*a):
            if self.client_index < len(clients):
                gone = clients.pop(self.client_index)
                tomb = self.app.data.setdefault("_deleted", [])
                tomb.append(gone.get("id"))
                tomb.extend(i.get("id") for i in gone.get("invoices", []))
            self.app.save()
            popup.dismiss()
            self.app.go_main()

        yes.bind(on_release=do_delete)
        no.bind(on_release=lambda *a: popup.dismiss())
        popup.open()


class AddInvoiceScreen(Screen):
    def __init__(self, app, client_index, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.client_index = client_index
        self.items = []
        self.build_ui()

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header(
            "إضافة فاتورة", ORANGE,
            on_back=lambda *a: self.app.go_client(self.client_index,
                                                  back=True)))
        body = make_body(padding=[dp(12), dp(8), dp(12), dp(10)])
        (form, self.item_name, self.item_qty, self.item_price,
         self.item_note, self.item_disc) = build_item_form(self.add_item)
        body.add_widget(form)
        body.add_widget(mk_text("الأصناف المضافة", dp(14), MUTED,
                                height=dp(24)))
        scroll, self.items_layout = make_scroll_list(spacing=dp(8))
        body.add_widget(scroll)

        total_card = CardBox(orientation="horizontal", size_hint_y=None,
                             height=dp(50), padding=[dp(14), 0],
                             bg=SOFT_BLUE, shadow=False)
        self.total_dt = mk_text("الإجمالي: 0 ريال", dp(18), PRIMARY,
                                halign="center", hint_y=1)
        total_card.add_widget(self.total_dt)
        body.add_widget(total_card)

        save_btn = mk_btn("حفظ الفاتورة", height=dp(52), font_size=dp(17),
                          background_color=GREEN)
        save_btn.bind(on_release=self.save_invoice)
        body.add_widget(save_btn)

        root.add_widget(body)
        self.add_widget(root)
        self.refresh_items()

    def add_item(self):
        it = parse_item(self.item_name, self.item_qty, self.item_price,
                        self.item_note, self.item_disc)
        if it is None:
            return
        self.items.append(it)
        self.refresh_items()

    def refresh_items(self):
        self.items_layout.clear_widgets()
        for i, it in enumerate(self.items):
            self.items_layout.add_widget(
                make_item_row(it,
                              on_delete=lambda idx=i: self.remove_item(idx)))
        total = sum(item_total(it) for it in self.items)
        self.total_dt.text = f"الإجمالي: {money(total)} ريال"

    def remove_item(self, idx):
        if 0 <= idx < len(self.items):
            self.items.pop(idx)
            self.refresh_items()

    def save_invoice(self, *a):
        if not self.items:
            return
        total = sum(item_total(it) for it in self.items)
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        c = clients[self.client_index]
        c.setdefault("invoices", []).append({
            "id": gen_id(),
            "kind": "فاتورة",
            "date": now_str(),
            "items": list(self.items),
            "total": total,
            "mod": now_full(),
        })
        c["balance"] = c.get("balance", 0) + total
        self.app.save()
        self.app.go_client(self.client_index, back=True)


class AddReceiptScreen(Screen):
    def __init__(self, app, client_index, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.client_index = client_index
        self.build_ui()

    def build_ui(self):
        root = BoxLayout(orientation="vertical", spacing=0)
        root.add_widget(make_header(
            "سند قبض", GREEN,
            on_back=lambda *a: self.app.go_client(self.client_index,
                                                  back=True)))
        body = make_body(padding=[dp(12), dp(8), dp(12), dp(10)], spacing=dp(10))

        clients = self.app.data.get("clients", [])
        c = clients[self.client_index] if self.client_index < len(clients) else {}
        card = CardBox(orientation="vertical", size_hint_y=None, height=dp(250),
                       padding=[dp(14), dp(12)], spacing=dp(4))
        card.add_widget(mk_text(f"العميل: {c.get('name', '')}", dp(17),
                                PRIMARY, height=dp(30)))
        card.add_widget(mk_text(
            f"الرصيد الحالي: {money_signed(c.get('balance', 0))} ريال",
            dp(13), MUTED, height=dp(24)))
        card.add_widget(mk_text("المبلغ المقبوض)ريال(", dp(13), MUTED,
                                height=dp(24)))
        self.amount_input = mk_input(input_filter="float", hint_text="0",
                                     size_hint_y=None, height=dp(50))
        card.add_widget(self.amount_input)
        card.add_widget(mk_text("ملاحظات )اختياري(", dp(13), MUTED,
                                height=dp(24)))
        self.note_input = mk_input(hint_text="مثال: دفعة نقدية",
                                   size_hint_y=None, height=dp(50))
        card.add_widget(self.note_input)
        body.add_widget(card)

        save_btn = mk_btn("حفظ سند القبض", height=dp(52), font_size=dp(17),
                          background_color=GREEN)
        save_btn.bind(on_release=self.save_receipt)
        body.add_widget(save_btn)
        body.add_widget(Widget())
        root.add_widget(body)
        self.add_widget(root)

    def save_receipt(self, *a):
        try:
            amount = float(self.amount_input.text.strip())
        except ValueError:
            return
        if amount <= 0:
            return
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        c = clients[self.client_index]
        note = self.note_input.text.strip() or "دفعة نقدية"
        c.setdefault("invoices", []).append({
            "id": gen_id(),
            "kind": "سند قبض",
            "date": now_str(),
            "items": [{"name": note, "qty": 1, "price": amount}],
            "total": amount,
            "mod": now_full(),
        })
        c["balance"] = c.get("balance", 0) - amount
        self.app.save()
        self.app.go_client(self.client_index, back=True)


class InvoiceDetailScreen(Screen):
    def __init__(self, app, client_index, invoice_index, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.client_index = client_index
        self.invoice_index = invoice_index
        self.edit_mode = False
        self.items = []
        inv = self._get_invoice() or {}
        self.is_receipt = inv.get("kind", "فاتورة") != "فاتورة"
        self._form_h = dp(176) if self.is_receipt else dp(420)
        self.build_ui()
        self.refresh()

    def _get_invoice(self):
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return None
        invoices = clients[self.client_index].get("invoices", [])
        if self.invoice_index >= len(invoices):
            return None
        return invoices[self.invoice_index]

    def build_ui(self):
        accent = GREEN if self.is_receipt else INV_RED
        root = BoxLayout(orientation="vertical", spacing=0)

        self.edit_btn = mk_btn("تعديل", size_hint=(None, None),
                               size=(dp(76), dp(38)), font_size=dp(14),
                               background_color=GLASS)
        self.edit_btn.bind(on_release=self.toggle_edit)
        root.add_widget(make_header(
            "تفاصيل السند" if self.is_receipt else "تفاصيل الفاتورة",
            accent,
            on_back=lambda *a: self.app.go_client(self.client_index,
                                                  back=True),
            right_widget=self.edit_btn))

        body = make_body(padding=[dp(12), dp(8), dp(12), dp(10)])
        summ = CardBox(orientation="vertical", size_hint_y=None, height=dp(76),
                       padding=[dp(14), dp(8)])
        self.client_dt = mk_text("", dp(17), TEXT, hint_y=0.55)
        self.info_dt = mk_text("", dp(13), MUTED, hint_y=0.45)
        summ.add_widget(self.client_dt)
        summ.add_widget(self.info_dt)
        body.add_widget(summ)

        body.add_widget(mk_text(
            "بيانات السند" if self.is_receipt else "الأصناف",
            dp(14), MUTED, height=dp(24)))
        scroll, self.items_layout = make_scroll_list(spacing=dp(8))
        body.add_widget(scroll)

        if self.is_receipt:
            self.form_card = CardBox(orientation="vertical",
                                     size_hint_y=None, height=dp(176),
                                     padding=[dp(12), dp(10), dp(12), dp(12)],
                                     spacing=dp(4))
            self.form_card.add_widget(mk_text("المبلغ المقبوض )ريال(",
                                              dp(13), MUTED, height=dp(20)))
            self.amount_in = mk_input(input_filter="float", hint_text="0",
                                      size_hint_y=None, height=dp(46))
            self.form_card.add_widget(self.amount_in)
            self.form_card.add_widget(mk_text("ملاحظة )اختياري(",
                                              dp(13), MUTED, height=dp(20)))
            self.note_in = mk_input(hint_text="مثال: دفعة نقدية",
                                    size_hint_y=None, height=dp(46))
            self.form_card.add_widget(self.note_in)
        else:
            (self.form_card, self.new_name, self.new_qty, self.new_price,
             self.new_note,
             self.new_disc) = build_item_form(self.add_item)

        total_card = CardBox(orientation="horizontal", size_hint_y=None,
                             height=dp(50), padding=[dp(14), 0],
                             bg=SOFT_BLUE, shadow=False)
        self.total_dt = mk_text("", dp(18), PRIMARY, halign="center", hint_y=1)
        total_card.add_widget(self.total_dt)
        body.add_widget(total_card)

        self.bottom = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(8))
        self.save_btn = mk_btn("حفظ التعديلات", height=dp(52),
                               background_color=BLUE)
        self.save_btn.bind(on_release=self.save_changes)
        self.del_btn = mk_btn("حذف", height=dp(52), background_color=RED)
        self.del_btn.bind(on_release=self.confirm_delete)
        self.wa_btn = mk_btn("إرسال واتساب", height=dp(52),
                             background_color=GREEN)
        self.wa_btn.bind(on_release=self.send_whatsapp)
        self._fill_bottom()

        body.add_widget(self.bottom)
        root.add_widget(body)
        self.add_widget(root)

    def _fill_bottom(self):
        self.bottom.clear_widgets()
        if self.edit_mode:
            self.bottom.add_widget(self.save_btn)
            self.bottom.add_widget(self.del_btn)
        else:
            self.bottom.add_widget(self.wa_btn)
            self.bottom.add_widget(self.del_btn)

    def refresh(self):
        inv = self._get_invoice()
        if inv is None:
            return
        clients = self.app.data.get("clients", [])
        c = clients[self.client_index]
        self.items = [dict(it) for it in inv.get("items", [])]
        self.client_dt.text = c.get("name", "")
        self.info_dt.text = f"{inv.get('kind','فاتورة')}  |  {inv.get('date','')}"
        if self.is_receipt:
            total = inv.get("total", 0)
            self.amount_in.text = f"{total:g}"
            self.note_in.text = self.items[0].get("name", "") if self.items else ""
        self.refresh_items()

    def refresh_items(self):
        self.items_layout.clear_widgets()
        for i, it in enumerate(self.items):
            if self.is_receipt:
                row = make_item_row(it, show_qty=False)
            elif self.edit_mode:
                row = make_item_row(it,
                                    on_delete=lambda idx=i: self.remove_item(idx))
            else:
                row = make_item_row(it)
            self.items_layout.add_widget(row)
        if self.edit_mode:
            self.form_card.height = self._form_h
            self.items_layout.add_widget(self.form_card)
        total = sum(item_total(it) for it in self.items)
        self.total_dt.text = f"الإجمالي: {money(total)} ريال"
        schedule_refresh(0.1)

    def add_item(self):
        it = parse_item(self.new_name, self.new_qty, self.new_price,
                        self.new_note, self.new_disc)
        if it is None:
            return
        self.items.append(it)
        self.refresh_items()

    def remove_item(self, idx):
        if 0 <= idx < len(self.items):
            self.items.pop(idx)
            self.refresh_items()

    def toggle_edit(self, *a):
        self.edit_mode = not self.edit_mode
        self.edit_btn.text = "إلغاء" if self.edit_mode else "تعديل"
        self.edit_btn.set_bg(RED if self.edit_mode else GLASS)
        self._fill_bottom()
        if self.edit_mode:
            self.refresh_items()
        else:
            self.refresh()
        schedule_refresh(0.1)

    def save_changes(self, *a):
        """يحدّث نفس الفاتورة (نفس الـ id) بدل ما يحذف ويضيف."""
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        c = clients[self.client_index]
        invoices = c.get("invoices", [])
        if self.invoice_index >= len(invoices):
            return
        old = invoices[self.invoice_index]
        old_kind = old.get("kind", "فاتورة")
        old_total = old.get("total", 0)
        old_id = old.get("id", gen_id())

        if self.is_receipt:
            try:
                amount = float(self.amount_in.text.strip())
            except ValueError:
                return
            if amount <= 0:
                return
            note = self.note_in.text.strip() or "دفعة نقدية"
            new_items = [{"name": note, "qty": 1, "price": amount}]
            new_total = amount
        else:
            if self.new_name.text.strip():
                pending = parse_item(self.new_name, self.new_qty,
                                     self.new_price, self.new_note,
                                     self.new_disc)
                if pending is not None:
                    self.items.append(pending)
            if not self.items:
                return
            new_items = list(self.items)
            new_total = sum(item_total(it) for it in self.items)

        # تحديث في المكان (نفس الـ id)
        if old_kind == "فاتورة":
            c["balance"] = c.get("balance", 0) - old_total + new_total
        else:
            c["balance"] = c.get("balance", 0) + old_total - new_total

        old["items"] = new_items
        old["total"] = new_total
        old["id"] = old_id
        old["mod"] = now_full()
        self.app.save()
        self.app.go_client(self.client_index, back=True)

    def confirm_delete(self, *a):
        content = BoxLayout(orientation="vertical", spacing=dp(10),
                            padding=dp(12))
        content.add_widget(mk_text("هل تريد حذف هذه العملية؟", dp(16), TEXT,
                                   halign="center", height=dp(44)))
        content.add_widget(Widget())
        bb = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        yes = mk_btn("نعم", background_color=RED)
        no = mk_btn("إلغاء", background_color=GRAY_BTN)
        bb.add_widget(yes)
        bb.add_widget(no)
        content.add_widget(bb)
        popup = make_arabic_popup("تأكيد", content, size_hint=(0.88, 0.38),
                                  title_color=RED, separator_color=RED)

        def do_delete(*a):
            clients = self.app.data.get("clients", [])
            c = clients[self.client_index]
            invs = c.get("invoices", [])
            inv = invs.pop(self.invoice_index)
            self.app.data.setdefault("_deleted", []).append(inv.get("id"))
            if inv.get("kind") == "فاتورة":
                c["balance"] = c.get("balance", 0) - inv.get("total", 0)
            else:
                c["balance"] = c.get("balance", 0) + inv.get("total", 0)
            self.app.save()
            popup.dismiss()
            self.app.go_client(self.client_index, back=True)

        yes.bind(on_release=do_delete)
        no.bind(on_release=lambda *a: popup.dismiss())
        popup.open()

    def send_whatsapp(self, *a):
        clients = self.app.data.get("clients", [])
        if self.client_index >= len(clients):
            return
        c = clients[self.client_index]
        inv = self._get_invoice()
        if inv is None:
            return
        mode = "receipt" if self.is_receipt else "invoice"
        show_document_popup(c, inv, mode, self.invoice_index + 1)
