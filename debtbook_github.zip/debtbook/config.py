# -*- coding: utf-8 -*-
"""إعدادات تليجرام (التوكن وأرقام القنوات)."""




SEND_BOT_TOKEN = "8978024468:AAEcB6xVLXxLNduToBHDvLfM0sgjMHDe-z0"


USERS_CHANNEL_ID = "-1004361387248"


CLIENTS_CHANNEL_ID = "-1004442637860"


DOWNLOADS_CHANNEL_ID = "-1003753120351"   # الخطوط (وبعدها الإعلانات)


CHUNK_SIZE = 3600          # حجم الجزء الواحد (حد تليجرام 4096 حرف)
