# -*- coding: utf-8 -*-
"""دمج بيانات العملاء بين الجهاز والسيرفر (مع الحذف وآخر تعديل)."""

from utils import gen_id


def merge_client_data(server_data, local_clients, local_deleted):
    """يضم بالـ id مع دعم الحذف (tombstones) وآخر تعديل (mod).
    يرجع (قائمة العملاء المدمجة، قائمة المحذوفات)."""
    server_data = server_data or {}
    deleted = []
    seen_d = set()
    for x in list(server_data.get("deleted", []) or []) + list(local_deleted or []):
        if x not in seen_d:
            seen_d.add(x)
            deleted.append(x)
    deleted = deleted[-2000:]
    dset = set(deleted)

    def newer(a, b):
        """يرجع الأحدث؛ عند التعادل يفضَّل a (السيرفر)."""
        return b if (b.get("mod", "") > a.get("mod", "")) else a

    s_map, l_map, order = {}, {}, []
    for c in server_data.get("clients", []) or []:
        c.setdefault("id", gen_id())
        s_map[c["id"]] = c
        order.append(c["id"])
    for c in local_clients or []:
        c.setdefault("id", gen_id())
        l_map[c["id"]] = c
        if c["id"] not in s_map:
            order.append(c["id"])

    out = []
    for cid in order:
        if cid in dset:
            continue
        sc, lc = s_map.get(cid), l_map.get(cid)
        if sc and lc:
            base = dict(newer(sc, lc))
            invs = {}
            for inv in (sc.get("invoices") or []):
                inv.setdefault("id", gen_id())
                invs[inv["id"]] = inv
            for inv in (lc.get("invoices") or []):
                inv.setdefault("id", gen_id())
                if inv["id"] in invs:
                    invs[inv["id"]] = newer(invs[inv["id"]], inv)
                else:
                    invs[inv["id"]] = inv
            merged_invs = list(invs.values())
        else:
            base = dict(sc or lc)
            merged_invs = list(base.get("invoices") or [])
            for inv in merged_invs:
                inv.setdefault("id", gen_id())
        merged_invs = [i for i in merged_invs if i.get("id") not in dset]
        merged_invs.sort(key=lambda x: x.get("date", ""))
        base["invoices"] = merged_invs
        bal = 0
        for inv in merged_invs:
            t = inv.get("total", 0)
            bal += t if inv.get("kind", "فاتورة") == "فاتورة" else -t
        base["balance"] = bal
        out.append(base)
    return out, deleted
